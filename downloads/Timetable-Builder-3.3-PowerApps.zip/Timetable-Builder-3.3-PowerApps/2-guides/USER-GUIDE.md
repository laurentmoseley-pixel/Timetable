# Timetable Builder: user guide

This guide is for the people who build the timetable and run the day: timetablers, senior leaders,
and office staff who arrange cover. The same help is inside the app: choose **Help** in the status
bar at the bottom, or press **Ctrl K** and type *help*.

## The screen

- **Home** is the page the app opens on. **To do** lists what needs you today, each with one button
  that goes straight to the job: lessons nobody covers (**Find cover**), clashes (**Show me**), lessons
  still to place (**Place them**), staff below your minimums, unsaved work and backups. Below it are the
  headline numbers (staff away, cover, problems, teaching load, rooms in use), safety and staffing
  through the day, cover so far this term, and quick jobs. Home only shows things; nothing on it
  changes the timetable.
- **The menu on the left:**
  - **Home**
  - **Plan**: Timetable (was Build), Auto build, What if (was Scenarios), Insights
  - **Run the day**: Staff day, Today, Cover
  - **Look up**: People and rooms (Staff, Students and Rooms, with a switch at the top), Reports
  - **More** (click to open; it stays open until you close it): Subject choices (was Options), Rest
    days and on call (was Rota), Transport, One person (was Individual)
  - **Set up**: Setup

  Search (**Ctrl K**) still finds pages by their old names.
- **Take the tour** (on Home, or File, Help) shows where everything is in seven short steps. Escape ends it.
- After each save, the status at the top shows a **Saved** tick for a moment. Hover over Save, Undo or
  Search to see their keyboard shortcuts; press **?** for the full list. On a phone, the menu is a bar along the
  bottom.
- **The header** shows:
  - the page you are on
  - search (**Ctrl K**), to jump to any page, person, class or job
  - where the timetable is kept
  - the bell, for telling people about changes
  - Undo and Redo, Save, and the **File** menu
- **The status bar** at the bottom shows:
  - whether your work is saved
  - any problems to put right, and the quality score (click it for Checks)
  - how big the timetable is
  - Help
- **Appearance:** File menu, then Light, Dark, High contrast or Automatic. There is also an
  easier-to-read font.
- **Look (trial):** File menu, then Classic or Future. Future is a new look: glass panels, a soft
  background light, glowing highlights and monospace times. It changes how the app looks, not what
  it does. It works with Light, Dark and Automatic; High contrast always uses the plain style, and so
  do printouts. **Reduce effects** (next to it) turns off the glass, glow and movement. Your choice is
  remembered on this computer.

## Starting

A new, empty timetable opens with a **welcome screen**:

- **Look around with a demo school.** A made-up school, to try everything. Choose **Start my own
  timetable** when you are ready.
- **Set up my school, step by step.** Name the school and timetable, choose the school days, and
  set how many lessons there are, how long they are, and when break and lunch fall.
- **Bring in what we have.** An Excel workbook, the Excel template filled in, TimeTabler exports,
  or a backup file.

Then, in **Setup**, add staff, pupils, groups (classes and sets), subjects and rooms. You can type
them, paste a list, or bring in the CSV templates. The **Getting started** list on the Today page
shows what is left to do.

## Building the timetable

- **Timetable** shows one row per group and one column per period. Click a slot to add or change a
  lesson in the editor on the right.
- **Drag** a lesson to move it. Hold **Ctrl** to copy it. While you drag, the group's row shows:
  - **green** where it fits
  - **amber** where it fits but replaces a lesson or repeats the subject that day
  - **red** where it would break a rule

  If you drop it where it breaks a rule, the app asks first.
- **Alt and the arrow keys** move the chosen lesson a period or a day at a time.
- In the lesson editor:
  - **Where it fits** lists every free slot.
  - **Fix it for me** finds the best place, moving as little as possible, and shows the changes
    before making them.
- **Lock** a lesson that must never move.
- **Auto build**:
  - Give each group a **weekly plan**: how many lessons of each subject, double or single, which days
    and times.
  - **Build the whole timetable** then fills the gaps, improves what is there, or rebuilds from the
    plans. It runs in the background, keeps to the rules, and shows the result before anything
    changes. **Undo** puts it back.
- **Subject choices** (under More; was Options) builds option blocks, where pupils split into the subjects they chose.

### Two lessons in one period (halves)

A class can have two lessons in one period, one after the other: for example Reading, then Regulation.
The bell times do not change.
- In the lesson editor, **Part of the period**: **All of it**, **First half** or **Second half**.
- Or drag one lesson onto another and choose **One after the other**. The lesson that was there becomes
  the first half.
- To set several at once, select them and choose **First half** or **Second half** in the editor.

Two halves of a period never clash, even with the same staff, students and room. The Timetable grid shows
**1st half** and **2nd half**. The staff Viewer shows First half and Second half, and the Lessons sheet of the
workbook has a **Half** column.

### Adding a lesson to an empty slot

Click the empty slot. The lesson editor shows up to three **Suggested** lessons: the subjects this class
usually has at that time on other days (or, failing that, the ones it has most), each with the adults and
room it usually has, **if they are free then**. Click one to add it, with the class's student list. Or pick
any subject below the suggestions, as before.

### A long lesson for one pupil, alongside the group

Click the first period, add the lesson (or click it if it is there), and set **Length**. Length goes up to
the end of the day. If the later periods already have lessons, you are asked:
- **Keep both, for some pupils:** it runs alongside the group's lessons and starts with nobody on it.
  Add the pupil (for example one pupil all day, periods 1 to 8).
- **Keep both, with the whole group:** it runs alongside, with the same pupils.
- **Replace them:** the lessons at those times go, as before. Undo brings them back.

If a pupil on it is also on another of the group's lessons at those times, the editor says so, with
**Take them off the other lessons**.

**Copying it to other days or slots** (Copy this … to other slots, or Copy the selection to other days)
asks what to do if a slot already has a lesson:
- **Replace it** (as before)
- **Keep both: run alongside it**
- **Keep both, and take these pupils off the other lesson there**

A lesson for part of the group starts on the last one, so the group's lessons stay and the pupil moves.
A whole-group lesson starts on Replace. Paste (Ctrl+V) still replaces; drag and drop asks.

### Editing on People and rooms

You don't need to go to the whole Timetable to change one person's lessons. On **People and rooms**
(Staff, Students or Rooms):

- **Click a lesson** to open the lesson editor beside the grid. Changes are made there, on that page. The
  lesson is outlined on everyone who is in it.
- **Click an empty slot** to add a lesson for that person or room:
  - **Students:** the lesson goes in the pupil's class with only that pupil on it, alongside whatever the
    class has then. Nothing of the class's is replaced. Pick a subject, then add staff and a room.
  - **Staff and Rooms:** choose the class first (the classes they are most often with come first), then a
    subject. They go on it as staff, or it goes in that room.
- **Right-click a lesson** for the quick menu (Edit, Swap, Change room, Copy, Lock, Delete).
- **Open in Timetable** in the editor shows the same slot in the whole Timetable.
- Click a name for their whole timetable, as before.

### Reading the grid

- **Hover** over a lesson (or tab to it) for a card with all of it: subject, when, group, room, staff by
  name and students.
- **Compact** or **Comfortable** (above the grid) sets how big each lesson is. Compact fits more on
  screen; Comfortable has bigger text. Your choice is remembered on that computer.
- **Colour key and tips** (above the grid) opens the colour key and the tips for selecting, moving and
  copying.

### The quick menu on a lesson

Right-click a lesson on the Timetable grid (or press **Shift+F10** on the chosen lesson, or press and hold it on a
touch screen) for: **Edit**, **Swap or replace a member of staff**, **Change room**, **Copy to other slots**,
**No staff needed**, **Lock** or **Unlock**, and **Delete**. Undo works for all of them.

In the lesson editor, the **Room** list puts the rooms that are free at that time first, and says how many are
free. Rooms in use say what is in them. The **Add staff** list already puts free people first.

### Dragging lessons

Drag a lesson to move it; hold **Ctrl** (or Alt) to copy it.
- **To an empty slot:** it moves. If it lands next to the same subject for the same pupils, you can also
  join the two into a double.
- **Onto another lesson:** a menu asks what to do.
  - **Swap places**: the two lessons change places.
  - **Merge into...**: one lesson, the one already there, with both sets of staff and students.
  - **One after the other**: a half each.
  - **Keep both at the same time**: for a 1:1 or a split group beside it.
  - **Replace**: the lesson already there is deleted.
  - **Cancel**, or press Escape.
- **Onto another lesson in the same period** (for example one of three 1:1s): **Merge into** makes them one
  lesson, or **One after the other** gives each half the period. To merge every lesson in a period, open
  one and choose **Merge these ... into one**; for many periods, select them and choose **Merge each period
  into one lesson**.
- **Into another class's row:** a whole-class lesson takes that class's list.

Anything that breaks a rule asks first. **Undo** puts any of these back.

### Classes with more than one lesson in a period

A class can have more than one lesson at once: a 1:1 beside the group, or the group split in two. When
you change a whole week (click a class's name on the Timetable grid to select its week, or use **Add to class
team and all its lessons**), the app keeps those lessons apart:
- Someone added to all the lessons goes in one lesson per period: the main one, with most students.
  Nobody is put in two lessons at once, and the app says where the class was split.
- **Set to class list** leaves pupils in their 1:1 or small group; the main lesson gets the rest.
- Copying to other days copies every lesson in each period, and **Join into one block** joins each group
  of students with itself.

### Adding someone to all of a class's lessons

In **Setup, Staff**, tick the person (or several people), choose the class in the list, then choose **Add to class team and all its lessons**. They go on every
lesson of that class and join its team. **Team only** adds them to the team without changing lessons.
In **Auto build**, each member of a class's **Staff team** shows how many of its lessons they are on,
with **Put on all its lessons**. **Take off all its lessons** does the opposite. If they are already teaching somewhere else at one of
those times, the app says how many clash; **Checks** lists them.

### Taking someone off the timetable, or swapping them

The quickest way is **Swap or replace a person**. Open it from Home (Quick jobs), from **One person** (when it
shows a member of staff), from a lesson's quick menu, or by searching (**Ctrl K**). Then:

1. **Who comes off.** Type part of a name and choose them. From a lesson, its adults are listed.
2. **Which lessons.** This lesson only, all of that class's lessons, or all their lessons.
3. **Who goes on instead.** People who are free for every one of those lessons come first, marked **Free**.
   Others say how many they are busy for. **Nobody** just takes the person off.

Before you confirm, it says what will happen. If the new person is teaching or not working at some of those
times, it says **"3 of these clash"**, names them, and offers to **leave those with** the person coming off,
so nothing clashes. Swapping all of a person's lessons also swaps their class team places. Undo puts it
all back.

The older way still works, in **Setup, Staff**:
- **Take off every lesson**: tick the person (or several), then choose it. They come off every lesson and
  every class team, but stay on the staff list. The app asks first.
- **Swap on all their lessons**: tick the person leaving, choose who takes over in **Swap for…**, then
  choose it. The new person gets every one of their lessons and their class team places. If the new person
  is already teaching at some of those times, the app says how many clash; **Checks** lists them.

Both can be undone.

### Blocked time: PPA, ECT time, meetings and more

Blocked time is part of a person's usual week that is not a lesson: **PPA**, **ECT time**, a **Meeting**,
**Maintenance**, or **Other**.
- No lesson is placed there. Auto build keeps lessons off it, the lesson editor and suggestions don't offer
  that person then, and a lesson already there is listed in **Checks** to move.
- It never needs cover when they are away, and they are not asked to cover during it.
- Their timetable shows the type (PPA, Meeting and so on) in the staff Viewer, on Staff day and on printouts.
  The note is only seen in the Builder.

**To add it for several people at once**, use **Setup, Blocked time**. Choose who (one or more people, or
Everyone, All teachers, or All TAs and support staff), what it is, an optional note, and the days and
periods. Then choose **Block out this time**. The list below shows all blocked time, with **Remove**.

**To add it for one person**, open **People and rooms, Staff** and click an empty slot. Choose **Block out:
PPA** (or another type). Click a blocked slot to change its type, repeat it at that time every day, or
remove it. Undo works for all of these.

In the Excel workbook, the Staff sheet has a **Blocked time** column, for example
`Wed P6 Meeting (Phase meeting); Fri P2 PPA`.

### Students with no staff

**Checks** flags any lesson with students on it and no staff, and the Timetable grid marks it red. If the
lesson does not need staff (college, work experience, an off-site placement), tick **No staff needed for
this lesson** in the lesson editor, or **No staff needed for any ... lesson** for every lesson of that
subject. Checks has the same two buttons by each lesson, and **Setup, Subjects** has a **No staff needed**
column.

### Tidying names (one name for one thing)

When the same thing has several names, reports and searches split it up.
- **Setup, Subjects** shows **Names that look like the same thing**. It finds every alternative provision
  name (Alt Provision, Alternative Provision, AP - ...), offsite names, reduced timetable names, 1:1 names, and
  names that differ only in capitals or punctuation. Untick any that are something different, check the
  name in **Merge as** and the start of the titles in **Titles start with** (AP: or Offsite: to begin with),
  then choose **Merge the ticked ones**. Each lesson keeps which provision it is in its title, for example
  AP - Player Ready becomes Alternative provision, titled **AP: Player Ready**.
- To merge any subjects yourself, tick them in the Subjects list, type the name, and choose **Merge into
  one**. **Keep old names as lesson titles** (the default) keeps the detail, after whatever you type in
  **Titles start with**: with AP: typed, AP - Player Ready becomes Alternative provision, titled AP: Player
  Ready. Generic names (Alt Provision, Off Site) get no title, as they say nothing extra.
- **Setup, Rooms** has **Merge into one** too, for example Offsite_RSPCA into Offsite Provision.
- In **Reports, Who is doing what**, **Change all of these lessons** gives every lesson the search found one
  subject or one title.

Everything that used the old names follows: lessons, plans, options, specialisms and iSAMS codes. Undo
puts it back.

### Who is doing what (Reports)

At the top of **Reports**, type what to look for, or choose a button: **Reduced timetable**, **Alternative
provision**, **Off site**, **1:1**, **College** or **Not on site**. It searches every lesson's subject, title, room
and group in the usual week, and lists:
- each student on those lessons, their group, how many periods a week and when
- each member of staff, how many periods a week and when
- every matching lesson (open **Every lesson**)

**Download as a spreadsheet (CSV)** saves the lessons with their staff and students. Words match loosely:
"alternate provision", "Alt Provision" and "AP - Equine" are all found by Alternative provision, and
"Reduced TT" by Reduced timetable. The report holds pupils' names, so keep printouts and downloads secure.

### More than one site

For a school on several sites, give each room its **Site** in **Setup, Rooms**, and set **Minutes to
move between sites** (in the **Checks** window, or on the School sheet of the workbook). Then:

- **Timetable** puts each site's classes together under a heading with the site's name and colour.
  - The **Site** menu on the toolbar shows one site at a time. Clicking a site heading does the same;
    clicking it again shows all sites.
  - Untick **Group by site** for the usual order; each row then says its site under the class name.
  - A lesson in a room on another site from its class shows that site's name, such as **South**.
- A class is based on the site of the rooms most of its lessons are in. To set it yourself, type it in
  the **Site** column of **Setup, Classes and groups**, or on the **Groups** sheet of the workbook.
- **Rooms** shows each room's site under its name.
- The lesson editor's room list names the site of any room on another site.
- The rule **not enough time to move between sites** still flags staff and pupils who would have to
  move between sites without enough time.

A school on one site sees none of this.

### Printing a timetable for one person

Open **More**, then **One person**. Choose staff or students and the look, then **Print** (this person) or
**Print all**. Each person's timetable prints on **one A4 landscape page**. If a week is very full, it is
printed slightly smaller, only as much as it needs; nothing is left out. The visual Day look still prints a
page for each day.

**Show: Staff, Pupils** (Standard look) chooses whether each lesson lists the staff and the pupils on it.
Staff are shown and pupils hidden to begin with. On a student's timetable, ticking Pupils lists the other
pupils in each lesson, and the page warns that this copy is not for giving to the pupil. Printing follows
your choice, and it is remembered on this computer. The visual looks have their own choices.

**Site** (for a school on more than one site) shows, and prints with Print all, only the groups, rooms, staff
or pupils on that site. Someone who works on two sites is on both.

### Printing the whole timetable

**Print the whole timetable…** (on One person, on Reports, or Ctrl K) prints one sheet with a row for each
group, member of staff or room, and every period of the week across the page, like a master timetable.
- **One row for each:** group, member of staff, or room.
- **Site:** all sites, **Each site on its own pages**, or one site.
- **In each lesson:** staff codes, room, and subject colours, each on or off.
- **Paper:** A4 or A3 landscape (it suggests A3 when there are more than 30 periods a week). For A3, choose
  A3 in the printer settings too.

Rows carry on to the next page, with the days and periods repeated at the top. A key at the end explains
the subject and staff codes. For staff, blocked time shows its type (PPA, Meeting) and times they don't
work show Off. Your choices are remembered on this computer.

**Order** sorts the list, and Print all, by surname (the default) or first name, A to Z, or as in the
list. Your choice is remembered on this computer.

### Checks and the quality score

The **Checks** button, or the status bar, opens the Checks window.

**Rules broken** must be put right:
- someone in two places at once
- staff timetabled when they do not work
- a room that is too small, or the wrong kind of room
- a group short of adults for its ratio
- pupils who must be kept apart taught together
- not enough time to move between sites

**The quality score** (out of 100) shows how well the timetable meets the school's preferences.
You choose how much each part counts:
- subjects spread across the week
- core subjects in the morning
- no empty periods in a group's day
- no long gaps in a teacher's day
- few room changes
- difficult slots shared fairly
- key adults with their pupils

### Snapshots and scenarios

- **Snapshots** (File menu) keep a copy of the lessons to compare with later or go back to. One is
  taken automatically before big changes.
- **What if** (was Scenarios) keeps scenarios: full working copies of the timetable, for trying ideas such as setting Year 9,
  or a teacher going part-time:
  - Open one, and every planning tool works on the copy. The real timetable, cover and the
    day-to-day pages are not affected.
  - Compare up to three scenarios with the real timetable, then **Use as the real timetable**.
    Undo works.

### Insights

**Insights** shows:
- the headline numbers
- each person's **workload**, against the most they should teach
- how many staff are **free to cover** in each period
- **rooms** in use
- **groups** against their weekly plans
- **pupils with no lesson**
- whether **cover is shared fairly** this term

Each part downloads as a spreadsheet.

**Print the meeting pack** (on Reports, in Home's Quick jobs, or through Ctrl K) prints one report for an
SLT meeting in a single click:
1. **Staffing load:** each person's periods a week, free periods, longest run and days with no break
2. **Cover:** how many each person has covered this term, against the average
3. **Room use:** how much of the week each room is used
4. **Problems:** clashes, rules broken, warnings and lessons still to place

It names staff only; there is no pupil data in it.

## Running the day

- **Cover**:
  - Mark who is off: a whole day, part of a day, or several days.
  - The buttons along the top:
    - **Cover this day** chooses cover for every lesson that needs it on the day shown. Cover already
      chosen stays.
    - **Print or copy** has Print who is covering, Copy who is covering, Print cover slips and Print
      full cover sheets.
    - **Several days, redo or clear** opens the date range with **Cover these days**, **Redo automatic
      cover** and **Clear cover choices** (which asks first).
  - Automatic cover chooses fairly, in this order:
    1. people called in
    2. people who can take a colleague's whole day
    3. people on call
    4. whoever has covered least

    It keeps to each person's cover limit for the term, and roles marked last resort are only
    used when nobody else is free.
  - Add **work** for each covered lesson.
  - Print slips, or copy the list.
- **This week** on Cover shows each day at a glance. Click a day to open it.
- **Today** has the safety checks (DSLs, first aiders and senior staff in), pupils who are off, and
  the daily briefing.
- **Staff day** shows each person's day, including cover. The **staff view** (File menu) shows the
  same for everyone, with nothing to edit.
- **Rest days and on call** (under More; was Rota) handles rest days and on-call lists. **Transport** books vehicles and drivers.

### Telling people

The **bell** counts staff with changes they have not been told about:
- new or cancelled cover and duties
- being called in
- changes to their weekly timetable

For each person there is a ready-written message. You can:
- send it by **Email** or **Teams chat** from your own account
- **Copy** it
- download a **Calendar file**
- **Put it in the outbox**

Then mark the person as told. In the Power Apps edition, a flow your IT team sets up can send the
outbox, and the bell shows what was sent.

### A summary of changes for all staff

At the top of the bell's window, **Summary of changes for all staff** is one short list of what has changed
in the usual week, by group, ready to send to everyone:
- new, moved and removed lessons
- new rooms and changes of staff
- PPA, meetings and other blocked time, by type (never the note)

It has no pupil names, no cover and no reasons for absence.

1. The first time, choose **Start from now**. Changes after that are listed.
2. Type when the changes start, if you like (for example *Monday 23 November*). It goes in the heading.
3. Choose **Copy summary** and paste it into an email or a Teams post, or **Email it** to open an email, or
   **Print**.
4. Choose **Mark as sent**. The next summary lists only what changes after this. Undo works.

**Changes since** can also compare with any snapshot (File, Snapshots).

The bell's own messages to each person still work as before.

### Lesson registers (Power Apps)

In the Power Apps staff app, staff choose **Take register** on a lesson they teach or cover today.
They mark each pupil Present, Late, Absent or Out of lesson, then choose **Save register**. Pupils
the office has reported off are already marked Absent.

In the Timetable Builder, **Today**, the **Lesson registers** card shows who has taken each register
and which are missing. It can be downloaded as a spreadsheet.

### The staff Viewer

**Setup**, then **Staff viewer** (or **File**, then **Publish for staff**) makes a separate,
read-only page for staff. On a phone it opens on **Today**:
- today's changes (cover they are doing, rooms that have changed)
- **Now and Next** all day long: what is first before school, the lesson now with Room, Group and the
  other adults and the minutes left, the break, and what tomorrow starts with after school
- a search for a colleague, room or group
- the whole day, each lesson labelled

The other tabs are **Week**, **Find** (staff, rooms, groups, and students if allowed) and **Cover**.
**Display and settings** has text size and an easier-to-read font.

Tick what staff may see, then download one of these:
- **the Viewer for all staff**: one file, where each person picks their name once
- **a Viewer for each person**: a zip, with one file each holding only that person's days
- **the published copy**: `timetable-published.json`, for a Viewer on the school's web site

Publish again when the timetable or cover changes. The Viewer never shows pupils, emails, notes or
reasons for absence. STAFF-VIEWER.md explains how to get it onto staff phones.

### The pupil Viewer

**Setup**, then **Pupil viewer** makes a very simple page for one pupil: what is on now and next with a
symbol, the room and their adult, a countdown, and a gentle note when a day is different. Download one
pupil's file, or a zip with one file for every pupil. Each file holds only that pupil's own timetable,
with no other pupil's name in it. You can add photos of adults if you wish. PUPIL-VIEWER.md has the
details.

## A new school year

**File**, then **New school year…** (or Ctrl K, "new school year") makes next year's timetable from a copy
of this one, in four steps:

1. **What to keep.** Staff, rooms, subjects, groups and class lists, the school day and rules are kept.
   Choose the lessons: keep this year's as a starting point, keep only locked lessons, or start empty.
   Absences and cover are not copied. Term dates are not copied unless you tick it.
2. **Year groups.** Every pupil moves up a year (Reception to Year 1, Year 7 to Year 8). Choose which year
   leaves; the leavers are named, and are taken off class lists and lessons in the new year.
3. **Name.** The name moves on a year (2026 to 2027 becomes 2027 to 2028), and you set the first day.
4. **Check and make.**
   - **Download the new year as a file** gives you next year's file and leaves this timetable as it is.
   - **Switch to it now** asks first. It then takes a snapshot of this year's lessons and downloads a
     backup of the whole timetable before switching. Undo goes straight back.

## Where the timetable is kept, and saving

Open **File**, then **Where your data is kept**, or click the chip by Save. The timetable can be
kept in:
- this file
- an Excel workbook
- a folder of CSV files
- Excel in OneDrive or SharePoint (Microsoft 365)
- Google Sheets
- Dataverse, in the Power Apps edition

**Save** writes to wherever it is kept:
- In Microsoft 365 or Google Sheets, if someone else saved since you opened it, you choose whether
  to open their version or save yours over it. A copy of yours is downloaded first.
- In the Power Apps edition, changes save by themselves.

Save a **backup file** (File menu) every week or two, and keep it in the school's own storage.

## Who can change it

**Setup**, then **Who can change this timetable**:
- **Can change everything.**
- **Cover and the day only:** Staff day, Today, Cover, Rest days and on call, and Transport.
- **Can look, not change.**

People are known by the account they sign in with: Microsoft 365, Google or Power Apps. You
cannot remove your own access by mistake.

## The school's look

**Setup**, then **Your school's look**: a logo for the menu, the staff view and printouts, and a
colour. The colour is adjusted if needed, so text stays easy to read.

## Personal data

**Setup**, then **Personal data**:
- **Everything about one person** downloads all the timetable holds about a member of staff or a
  pupil, for a subject access request.
- **Remove old records** deletes day-to-day records from before a date, after a backup. Agree how
  long to keep them with your data protection officer.

## The AI assistant (optional)

The AI assistant is off unless someone who can change everything turns it on, in **Setup**, then
**AI assistant**. Your IT team chooses the AI service and sets it up (see AI-PROVIDERS.md). Only
people who can change everything see the AI buttons.

**What it can do.** Look for the buttons marked with a spark:

| Button | Where | What it does |
|---|---|---|
| Fix all clashes | Timetable, the toolbar | Moves as few lessons as possible to clear the rule problems |
| Timetable this class | Auto build, each group | Places the lessons a group is missing from its weekly plan |
| Find cover | Cover, each person off that day | Chooses who covers each lesson, fairly |
| Balance this week | One person, a member of staff | Spreads one person's lessons more evenly |
| Explain this placement | The lesson editor | Says why a lesson is where it is, and whether a better slot exists |
| Run a what-if | What if, with a scenario open | Tries an idea you type, in the scenario only |
| Map my spreadsheet | Upload sheets | Matches a lessons sheet's columns when the app does not recognise them |

**How it works.**
1. The AI only ever sees codes, never names. You can choose to see exactly what is sent first.
2. The AI proposes. The app checks the proposal against its own rules. If anything fails, it tells
   the AI why and asks again, up to five times. If it still fails, nothing changes.
3. You see before and after, with each change listed. Choose **Approve**, **Edit** (untick the
   changes you do not want; the rest is checked again) or **Reject**.
4. Approving is one change, so **Undo** puts it back.

The AI never changes the timetable by itself. Locked lessons never move, an action for one group or
person cannot touch anyone else's lessons, and a what-if only changes the open scenario.

**In a what-if**, choose people, groups, rooms and subjects from the **Insert a person, group, room or subject** list rather than typing their
names. A typed name is not sent; the app asks you to use the list.

### Making your own AI buttons

**Setup**, then **AI assistant** lists where every AI button is, with **Go there** for each.
**Setup**, then **AI actions** lists every AI button.
- The seven official ones are locked. Untick **On** to hide one, **View** to see exactly how it works,
  or **Duplicate** to make your own version.
- **New action** opens a form: a name and button label, an icon, what it does (move lessons, choose
  cover, explain, or match spreadsheet columns), where the button goes, what data it may send, and
  the prompt. Insert placeholders such as `{{group_code}}` from the list. Problems are listed as you
  type, and it cannot be saved until they are put right.
- **Preview what it sends** shows the request, built from a made-up school; nothing is sent.
- **Try it on practice data** runs it on the made-up school, checked and reviewed like a real run,
  without touching your timetable.
- **Save** and the button appears on its page straight away, marked *Custom*. Each save is a new
  version; **Earlier versions** in the form loads an old one back.
- **Share** saves one action as a pack file; **Save your actions as a pack** saves them all. **Bring
  in an action pack** adds actions from a pack file. They come in switched off, so you can look at
  them and try them first.

A prompt cannot contain anyone's name, staff code or email. If a word is also part of someone's name
(like "will"), the form asks you to confirm it is an ordinary word there.

AI-ACTION-TEMPLATES.md describes the format, with examples.

## Keyboard shortcuts

Press **?** for the full list. The main ones:

| Keys | What they do |
|---|---|
| Ctrl K | Search or jump to anything |
| Ctrl S | Save |
| Ctrl Z / Ctrl Y | Undo / Redo |
| Arrow keys | Move around the timetable |
| Shift + arrows | Select a block of slots |
| Alt + arrows | Move the chosen lesson |
| Escape | Close a window, or clear the selection |
