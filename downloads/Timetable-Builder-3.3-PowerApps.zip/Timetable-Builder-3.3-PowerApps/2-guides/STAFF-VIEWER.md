# The staff Viewer

The Viewer is a separate, read-only page for staff. It has four tabs, each a big button along the bottom
of a phone:

- **Today**, which opens first:
  - **Updated** time at the top, with a gentle note if the copy is more than a week old
  - **Today's changes**: cover you are doing, rooms that have changed, lessons not with you today
  - **Now and Next**, all day:
    - before school: what you have first and when it starts
    - during a lesson: the subject in large type, then **Room**, **Group** and **With** (the other adults)
      on their own lines, and a bar showing the minutes left
    - at break: the break, and what is next
    - after school: what tomorrow starts with
  - **Find a colleague, room or group**: type a name and tap it
  - the whole day, each lesson labelled the same way
- **Week**: this week with its cover, or the usual week
- **Find**: Staff, Rooms, Groups and (if the school allows it) Students, with a switch at the top. It
  remembers which you used last.
- **Cover**: the cover board for each day

It also lists **what changed since you last looked**.

Nothing can be changed in it. It has no AI and sends nothing anywhere. It holds a **staff-safe copy**
of the timetable that the school publishes from the Timetable Builder.

## Publishing

In the Builder, open **Setup, Staff viewer** (or **File, Publish for staff**).

**What staff can see.** Tick what the copy may hold:

| Choice | Default | What it means |
|---|---|---|
| Anyone's timetable | On | The Staff tab, to look up a colleague's day and week. Off: each person sees only their own. |
| Rooms | On | Every room's week |
| Groups | On | Every group's week, with its staff |
| The cover board for each day | On | Who covers which lesson, each published day |
| Who is away | Off | The names of staff who are away each day. Never why. |
| School days ahead | 10 | How many school days, from today, the copy covers (1 to 30) |

Then choose one of three downloads:

1. **Download the Viewer for all staff.** One file for everyone. The first time each person opens it,
   they choose their name. It is remembered on their device only.
2. **Download a Viewer for each person (.zip).** One file per person, named after them, holding only
   their own days (and rooms, groups and the cover board, if ticked). It opens straight to their
   day. Use this when staff should not see each other's timetables.
3. **Download the published copy (.json).** The copy on its own, `timetable-published.json`, for a
   Viewer on a web site (below).

**Publish again** whenever the timetable or cover changes. A copy covers the days it was published
for. After that it says it has run out, and shows each person's usual week.

## What is in a copy, and what never is

**In it:**
- the school's name, logo and colour
- days, periods and times
- each lesson's group, subject (or lesson title), room and staff
- each published day as Staff day shows it: lessons, cover, extra duties, driving, swaps, and
  "Away", "Rest day" or "Not working" (no reasons)
- what the school ticked above

**Never in it:**
- pupils: names, codes, school numbers, lists or groups' pupils
- email addresses
- reasons or types of absence
- notes, notices or cover work
- the change log
- the AI settings or log

A pupil's name that reaches any text, such as a lesson title or a 1:1 duty, is replaced with
"a pupil".

## Live cover on staff computers (no Power Apps needed)

This keeps every Viewer on school computers up to date within about a minute of a change, for
example new cover. It uses OneDrive and SharePoint only: no app registration, links, keys, flows or
extra licences.

```
Builder (timetabler's PC)  ──saves within seconds──►  synced folder  ──OneDrive──►  SharePoint library
                                                                                    │
Viewer (staff PC)  ◄──reads every 20 seconds──  synced folder  ◄──OneDrive──────────┘
```

**Set up once (about 10 minutes):**

1. In SharePoint, make a library (or folder) that only staff can open, for example **Staff Timetable**.
   Use the site's permissions so staff can **read**, and only the timetablers can **edit**.
2. On the timetabler's computer, open the library in a browser and choose **Sync**. It now appears in
   File Explorer under your school's name.
3. In the Builder (in Edge or Chrome): **Setup, Staff viewer**, then **Choose the shared folder…**, and
   pick that synced folder. The staff copy (`timetable-published.json`) is saved there straight away.
   Then choose **Put the Viewer in this folder**.
4. Leave **Save by itself after every change** ticked. From now on every change, including cover, is
   saved there within seconds. OneDrive uploads it to SharePoint.

**For staff, once on each computer:**

1. Open the Staff Timetable library in a browser and choose **Sync** (or your IT team can push
   the sync to school computers).
2. In File Explorer, open the synced folder and double-click **Timetable-Viewer.html** (it opens in Edge
   or Chrome). Choose **Choose the folder…** and pick the same synced folder, then pick your name.
3. From then on the Viewer shows **Live** at the top. It checks the folder every 20 seconds and shows
   any change, with **changes since you last looked**. When opened again, the browser may ask once to
   **Reconnect**. Choosing "Allow on every visit" stops it asking.

**Things to know:**
- It works in Edge and Chrome on Windows and Mac. It does not work in Safari or on phones, because a
  web page on a phone cannot read a synced folder.
- The copy is saved as changes are made, even before the timetabler saves the Builder file itself. If
  a change is undone, the undo goes out too.
- The browser asks the timetabler to reconnect the folder when the Builder is next opened. The
  Builder shows a **Reconnect** button.
- Who can open it depends on the SharePoint library's permissions. Keep it staff-only.
- This sets things up for Power Apps later: the file in SharePoint is the same staff copy the
  Power Apps staff app uses (POWER-APPS-STAFF-APP.md).

## Getting it to staff

The Viewer can only show what is in the copy. **Who can open it depends on where you put it**,
because a file cannot check who is opening it.

- **On a computer:** double-click the file. It opens in any browser.
- **On a phone:** phones do not run web pages saved as files, so the Viewer needs a web address.
  - **The school's web site or intranet**, in an area only staff can reach. Upload
    the Viewer and `timetable-published.json` into the same folder. The Viewer then loads the
    newest copy by itself (every 10 minutes while open), so after that you only replace
    `timetable-published.json` when you publish again.
  - **Azure Static Web Apps** in the school's Microsoft 365 tenant, with Microsoft Entra sign-in so
    only staff can open it. Your IT team sets this up once, in the Azure portal in a browser.
  - Staff can then **add it to their home screen**, like an app.
- **SharePoint and Teams** keep files safe to share. However, SharePoint Online does not show web
  pages saved there: it downloads them instead. They work on a computer, not well on a phone.
- **Personal Viewers** can go into each person's OneDrive, or be sent to them, for use on a computer.
- **The Power Apps edition:** the Viewer can be its own staff app behind Microsoft 365 sign-in. It
  knows who is signed in, stays up to date by itself, works on phones through the Power Apps app,
  and adds lesson registers. See POWER-APPS-STAFF-APP.md.

## What changed since you last looked

The first time someone opens the Viewer, it notes their timetable and their published days. Each
time after that, it compares the copy with what they saw last. It lists what is different, with what
it was, and marks it on the day. **Got it** clears the list. This is kept only on their own device.

## Privacy

The Viewer keeps two things in the browser on the person's device: who they are, and what they last
saw. Nothing is sent anywhere. Its security policy lets it reach nothing but its own web site (to
load `timetable-published.json`). Staff names and timetables are still personal data. Put the
Viewer where only staff can reach it, and record it in your data protection records
(DATA-PROTECTION.md).

## Looks

The Viewer matches the Builder:
- **Appearance:** Automatic, Light, Dark or High contrast
- **Look:** Classic or Future
- the school's colour and logo

Each person chooses their look in **Display and settings** (the button at the top right), which also
has:
- **Text size:** Standard, Large or Largest
- **Font:** Standard or Easier to read (a clear font already on the device, with more space between
  letters and lines; nothing is downloaded)

Their choices are remembered on their device.

**A personal link.** When the Viewer is on the school's website, SharePoint or another web address,
adding `#me=` and a person's staff code to the end of its address opens it straight on that person, for
example `…/Timetable-Viewer.html#me=BHA`. Each person can also copy their own link from **Display and
settings**, **Copy my link**, and bookmark it or add it to their home screen. A link only chooses among
the people already in the Viewer; it does not show anything extra. In the day and week lists, cover is
marked with a **Cover** label and a bar down the side, not by colour alone. Buttons are at least 48 pixels, so they are easy to tap.


## Student timetables (optional)

Tick **Student timetables** in **Setup, Staff viewer** to add a **Students** tab to the Viewer. Staff type part
of a pupil's name and see that pupil's week: each lesson with its group, room and staff.

- It is **off unless you tick it**. Ticked, the staff copy holds every timetabled pupil's name, year and
  tutor group, and which lessons they are in. It never holds dates of birth, pupil numbers, notes or
  reasons for absence.
- Anyone who can open the Viewer can look up any pupil, so keep it where only staff can open it (the
  Power Apps staff app, a staff-only SharePoint library or Teams channel). Agree it with your data
  protection lead and add it to your records of processing.
- The Viewer does not remember which pupil was looked up.

## Visual timetables and what each lesson shows

- On **Students** and **Groups**, choose **Timetable**, **Visual week** or **Visual day**. The visual
  timetables use the subject symbols set in the Builder (Setup, Subjects), or the built-in Mulberry
  symbols. **Print** prints the one on screen.
- **Show** ticks (Adults, Students, Rooms, Groups) choose what appears on each lesson, down to just the
  subject. Each person's choice is remembered on their own device.
