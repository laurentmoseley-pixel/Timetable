# Timetable Builder: keeping the timetable in Microsoft 365 or Google Sheets

This is for the person who looks after IT. Every step is done in a web browser; nothing needs a
command line. Allow about 30 minutes.

When it is set up, staff open the Timetable Builder at a web address, sign in with their own school
account, and keep the timetable as a workbook in OneDrive or a SharePoint library, or as a Google
Sheet. Everyone the workbook is shared with opens the same timetable.

## How it keeps data safe

- **The app holds no timetable.** The copy on your web site is only the app. The timetable stays in
  your school's Microsoft 365 or Google Workspace, in a file you control and share like any other.
- **Each person signs in as themselves.** Microsoft sign-in uses Microsoft's own library (MSAL) with
  the *delegated* permission `Files.ReadWrite.All`. That means a person can only open files they could
  already open in OneDrive or SharePoint. Google sign-in uses Google's own sign-in page with the
  `spreadsheets` scope, plus `email` to show who is signed in.
- **No secrets anywhere.** The app needs only the app (client) IDs. These are public by design. The
  app refuses anything that looks like a client secret. Do not create a client secret or certificate.
- **Tokens stay in the browser tab.** Sign-in tokens are kept in the tab's session storage
  (Microsoft) or in memory (Google). They are never written into the timetable or the file.
- **Nowhere else.** The app's content security policy lets it connect to only these places:
  - `login.microsoftonline.com` and `graph.microsoft.com`
  - your `*.sharepoint.com` file downloads
  - `sheets.googleapis.com` and `www.googleapis.com`
  - its own web address

  There is no tracking or analytics.
- **Saves never collide silently.** If someone else saved the workbook since it was opened, the app
  says so. It downloads a copy of the person's own version first, then lets them choose which
  version to keep.

## 1. Put the app on a web address

Microsoft and Google only send a sign-in back to a web address registered for the app. So the app
has to be at an `https://` address. Use one of these:

| Option | Good for | How |
|---|---|---|
| Your school's own web server or intranet | Any school | Ask whoever runs it to publish one file, `index.html`, in its own folder. |
| Azure Storage static website | Microsoft 365 schools with Azure | See below. |
| GitHub Pages | Any school | See below. The file holds no school data, only the app IDs, so a public site is acceptable. |
| Netlify Drop | Any school | Drag a folder containing `index.html` onto app.netlify.com/drop, then claim the site with a free account. |

SharePoint document libraries download HTML files instead of running them, so SharePoint cannot
host the app itself. It can still hold the timetable workbook.

**Azure Storage static website**

1. In the Azure portal, create a Storage account (Standard, locally redundant is enough).
2. Open it, then go to **Data management**, then **Static website**. Choose **Enabled**, set the
   index document name to `index.html`, and save.
3. Copy the **Primary endpoint**, for example `https://ttschool.z33.web.core.windows.net/`.
4. Go to **Storage browser**, then **Blob containers**, then **$web**, then **Upload**. Upload the app
   file renamed to `index.html`.

**GitHub Pages**

1. Create a repository, for example `timetable`.
2. Choose **Add file**, then **Upload files**, and upload the app file renamed to `index.html`.
3. Go to **Settings**, then **Pages**. Choose **Deploy from a branch**, then `main` and `/ (root)`.
   The address is `https://<account>.github.io/timetable/`.

Use the exact address, including the final `/`, in the next steps.

## 2. Register the app with Microsoft (for OneDrive and SharePoint)

1. Go to the Microsoft Entra admin centre, then **Identity**, **Applications**, **App registrations**,
   and choose **New registration**.
2. Fill in the registration:
   - Name: `Timetable Builder`
   - Supported account types: **Accounts in this organizational directory only**
   - Redirect URI: platform **Single-page application (SPA)**, with the app's exact address from
     step 1
3. Choose **Register**.
4. Go to **API permissions**, then **Add a permission**, **Microsoft Graph**, **Delegated
   permissions**. Choose **Files.ReadWrite.All**, then **Add permissions**.
5. Optional, but it saves every member of staff a consent screen: choose **Grant admin consent**.
6. Do **not** add a client secret or certificate.
7. From **Overview**, copy the **Application (client) ID** and the **Directory (tenant) ID**.

## 3. Register the app with Google (for Google Sheets)

1. In the Google Cloud console, create a project, for example `Timetable Builder`.
2. Go to **APIs and services**, then **Library**. Find **Google Sheets API** and choose **Enable**.
3. Set up the OAuth consent screen (Google Auth Platform):
   - Audience: **Internal**, so only your Google Workspace accounts can sign in and no Google review
     is needed
   - Add the scopes `.../auth/spreadsheets` and `email`
4. Go to **Clients** (or **Credentials**), then **Create client**, type **Web application**:
   - Authorised JavaScript origins: the site's origin, for example `https://ttschool.z33.web.core.windows.net`
   - Authorised redirect URIs: the app's exact address from step 1
5. Copy the **Client ID**, which ends `.apps.googleusercontent.com`. Ignore the client secret that
   Google shows: the app never uses it.

## 4. Put the IDs into the app

1. Open the app at its web address. The app's file menu is at the top right.
2. Choose **File**, then **Where your data is kept**, then **Cloud sign-in (for your IT team)**.
3. Enter the Microsoft client ID and tenant ID (or your school's domain), and/or the Google client
   ID.
4. Choose **Try these on this computer** and test signing in.
5. Choose **Download the app for your web site**. This makes `timetable-builder.html` with the IDs
   built in and no timetable inside.
6. Rename it to `index.html` and upload it over the old one.

Instead of step 5, you can choose **Download timetable-config.json** and upload it next to
`index.html`. The app reads it from the same address.

## 5. First use

1. Open the app at its web address.
2. Choose **Where your data is kept**, then **Sign in with Microsoft** (or **Sign in with Google**).
3. Choose **Save to a new workbook in OneDrive** (or **Save to a new Google Sheet**). Or open an
   existing timetable workbook from its link.
4. Share the workbook with the colleagues who build the timetable (Can edit / Editor). To keep it in
   a SharePoint library, move it there and open it again from its link.
5. From then on, **Save** writes to that workbook. Each browser remembers which workbook it was using
   and offers to open it next time.

The workbook can still be opened in Excel or Google Sheets, and its sheets are the same as the Excel
template. Avoid editing it there while others are using the app. If you do edit it there, use
**Open it again** in the app afterwards.

## Troubleshooting

| What you see | What to do |
|---|---|
| "Microsoft does not know this web address" (AADSTS50011) | Add the exact address, with the final `/`, as a **Single-page application** redirect URI. |
| "An administrator needs to approve the app's permission" | Grant admin consent for Files.ReadWrite.All (step 2.5), or allow users to consent. |
| "Microsoft cannot find the app in your school's directory" | Check the client ID and tenant ID. |
| The sign-in window does not open | Allow pop-ups for the app's address. |
| Google says redirect_uri_mismatch | Add the exact address as an authorised redirect URI, and its origin as a JavaScript origin. |
| Google asks to sign in again every hour | This is expected: Google's sign-in lasts an hour. Saving asks first, and nothing is lost. |
| "The workbook is locked" | Someone has it open with changes in the Excel desktop app. Close it there. |
| Cloud choices say they need a web address | The app was opened as a file on a computer. Open it from its web address. |

## Taking it away

- Delete the app registration in Microsoft Entra and/or the OAuth client in Google Cloud.
- Remove `index.html` from the web site.

The timetable workbooks stay where they are, as ordinary files.
