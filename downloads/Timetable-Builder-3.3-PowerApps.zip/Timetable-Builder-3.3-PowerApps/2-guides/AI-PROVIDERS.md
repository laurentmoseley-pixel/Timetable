# The AI assistant: connecting an AI service

The AI assistant is optional. It is off until someone who can change everything turns it on, and
the Timetable Builder works fully without it. This guide is for the person who sets it up, usually
the school's IT team.

## How it works

```
the app ──► privacy gateway ──► adapter for the chosen service ──► the AI service
                 │                          │
   codes only, checked,               builds the request,
   shown first if you like            reads the answer
```

- **The privacy gateway** (`aiRun` in the app, with `src/lib/ai.js`) is the only code that sends
  anything to an AI. It builds just the data the action needs, as codes, scans the whole request for
  names, emails, staff codes and notes, and blocks it if it finds one. It can show you the request
  before sending. Answers are checked, retried once if they do not fit, then refused safely. The
  AI log records every request and answer, in codes.
- **An adapter** is a small object that turns the app's standard request into one service's format,
  and that service's answer back into the standard answer. Adapters never touch the network.

## Before you start: the AI-enabled copy

The app's security policy stops it connecting to anything except the school's own sign-in and
storage. So:

1. Open the app, then **Setup**, then **AI assistant**.
2. Tick **Use the AI assistant**, choose the service and, if asked, fill in its address.
3. Choose **Download the AI-enabled app**. You get a copy, with your timetable inside, that may
   reach that one service and nothing else.
4. Open that copy from now on. Enter the key, choose the model and choose **Test the connection**.

If you change service later, download the AI-enabled copy again.

The AI assistant section shows these steps numbered, with a **Next:** line saying what to do. The
key box only appears in the AI-enabled copy: a key typed into another copy would not carry across.

**The key.** Choose **Use for this session** to keep it in memory only (it goes when the window
closes), or **Remember on this computer** to keep it encrypted with a passphrase of at least 10
characters. You then type the passphrase once each time you open the app. A key is never put in the
timetable or the file, and the settings refuse anything that looks like one.

**Who should hold a key?** Anyone who uses a browser with the key in it could use the key. That is
fine for one timetabler trying the assistant out. For wider use, set up a **relay** (below), so the
key stays on the school's server.

## The services

The data notes below describe each provider's terms as of October 2026. Check the current terms
before you rely on them, and record your choice in the DPIA (docs/AI-PRIVACY.md).

### Claude (Anthropic)

1. Sign up at platform.claude.com (the Claude Console) and add credit under Billing. Set a spend
   limit.
2. Create a workspace for the timetable (for example "Timetable Builder").
3. Go to Settings, API keys (platform.claude.com/settings/keys), choose **Create key**, name it, choose
   an expiry and **select the workspace**. The app does not send a workspace header, so a key that
   is not scoped to a workspace is refused with "must include the anthropic-workspace-id header".
4. Copy the key (it starts `sk-ant-`). It is shown only once, so keep it in a password manager.
5. In the app, choose **Claude (Anthropic)**, download the AI-enabled copy and open it.
6. Paste the key and press Enter (or choose **Use for this session**). The models are listed: pick one
   (a smaller model such as Haiku is cheap and works well), then choose **Test the connection**.

Data: the API does not use your requests to train models by default. Ask Anthropic about zero data
retention if your DPO wants it. The app sends the header Anthropic requires for direct use from a
browser.

### OpenAI

1. At platform.openai.com, create a project and an API key. Set a budget limit.
2. Choose **OpenAI**, download the AI-enabled copy, open it, paste the key, **Find models**, pick one,
   test.

Data: API requests are not used for training by default. Zero data retention is available on request.

### Google Gemini

1. In Google AI Studio (or Google Cloud, Generative Language API), create an API key. Restrict it to
   the Generative Language API.
2. Choose **Google Gemini**, download the AI-enabled copy, open it, paste the key, **Find models**,
   pick one, test.

Data: use a paid (billed) project. Free-tier usage may be used to improve Google's products.

### Azure OpenAI (inside your Microsoft tenant)

1. In the Azure portal, create an **Azure OpenAI** resource, ideally in **UK South**, so data stays
   in the UK.
2. In Azure AI Foundry, deploy a model and note the **deployment name**.
3. In the resource, open **Keys and Endpoint**. Copy the endpoint (like
   `https://your-resource.openai.azure.com`) and Key 1.
4. In the app, choose **Azure OpenAI**, paste the endpoint, download the AI-enabled copy and open it.
   Paste the key, type the deployment name and test.

Data: covered by your Microsoft agreement. Prompts are not used for training. If the browser cannot
reach the resource (a CORS or network rule), use a relay in the same tenant.

### Local model (Ollama): nothing leaves the building

1. On a computer or server in school, install Ollama and pull a model that follows instructions well
   (for example a recent 8B to 70B model). Bigger models give better timetabling answers.
2. Ollama only answers pages it trusts. Your IT team sets the environment variable
   `OLLAMA_ORIGINS` once:
   - for the app opened as a file: `OLLAMA_ORIGINS=null`
   - for the app on a web site: `OLLAMA_ORIGINS=https://timetable.your-school.org.uk`
   Then restart Ollama. (On a server, also set `OLLAMA_HOST=0.0.0.0` and limit access with the
   firewall.)
3. In the app, choose **Local model (Ollama)** and set the address (`http://localhost:11434`, or the
   server's address). Download the AI-enabled copy and open it. No key is needed. **Find models**,
   pick one, test.

### The school's own relay (recommended for whole-school use)

A relay is a small web service the school runs (for example an Azure Function or a container in the
school's tenant). It holds the AI key and calls the AI for the app. The app only knows the relay's
address.

- The relay's address must start `https://` and **must not carry a secret**. A Power Automate
  trigger address (with `sig=`) is refused. The relay must check who is calling, for example with
  Microsoft Entra ID authentication, the school network, or a per-user token typed in like a key.
- **The relay contract.** The app sends a POST with JSON:
  ```json
  { "format": "tt-ai-1", "model": "", "system": "…", "prompt": "…", "schema": { … },
    "maxTokens": 4000, "temperature": 0.2 }
  ```
  The relay replies with `{ "data": { …the answer, matching the schema… } }`. It can also reply
  `{ "text": "…JSON…" }`, or `{ "error": { "message": "…" } }` with an error status.
  The relay must allow cross-origin requests from the app's address (CORS). It may answer with any
  AI service.

## Adding a new AI service (for developers)

Add one object to `ADAPTERS` in `src/lib/ai.js`. Nothing else changes: the settings list,
security policy, gateway, checks, log and actions all use it automatically.

```js
myservice: {
  label: 'My AI service',
  needsKey: true, keyHint: 'Where the key comes from',
  endpoint: 'https://api.myservice.example', fixedEndpoint: true,   // or endpointHint + checkEndpoint
  modelHint: 'What to type as the model',
  origins: cfg => ['https://api.myservice.example'],      // what the security policy must allow
  request: (req, cfg, key) => ({                           // req = { system, prompt, schema, maxTokens, temperature }
    url: 'https://api.myservice.example/v1/chat',
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
    body: { model: cfg.model, system: req.system, input: req.prompt, json_schema: req.schema }
  }),
  parse: j => ({ data: parseJson(j.output_text), usage: j.usage, model: j.model }),  // throw friendly errors
  models: { request: (cfg, key) => ({ url: '…/models', headers: { … } }), parse: j => j.models.map(m => m.id) }  // or null
}
```

Rules for an adapter:
- Build the request and read the answer, nothing else: never call `fetch` (the gateway does).
- Put the key only in a header, never in the address or the body.
- Return the answer as `data` (an object). Use `parseJson` for text answers. Throw an error with
  `friendly: true` for the service's own error messages.
- Add a stand-in for the service to `tests/fixtures/ai-standin.cjs` and its name to the services in
  `tests/ai.test.cjs`, then run `npm test`.

## Microsoft Copilot Studio and Power Automate

Not included yet, by choice. The school's rules do not allow a flow's trigger address in the app.
When it is added, it will work in the Power Apps edition through Dataverse rows answered by a flow,
like the outbox. Meanwhile, a relay in your tenant can call Azure OpenAI or Copilot.
