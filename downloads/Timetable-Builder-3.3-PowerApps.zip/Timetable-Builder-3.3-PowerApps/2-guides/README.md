# Timetable Builder

Build the school timetable, keep it right as things change, arrange cover fairly and tell people,
all in one app that keeps the school's data where the school chooses.

## What it does

- **Build.**
  - A timetable grid that checks every rule as you drag: nobody in two places at once, rooms that
    fit, ratios met, pupils kept apart, time to move between sites.
  - Two-week timetables.
  - Option blocks.
  - Weekly plans for each group, and **Build the whole timetable** to fill and improve it
    automatically.
- **Checks and quality.** Every rule in one window, and a quality score out of 100 against the
  school's own priorities.
- **Insights and scenarios.**
  - Insights: workload and fairness, staff free to cover in every period, rooms, and gaps.
  - Scenarios: full working copies for trying ideas, compared side by side with the real timetable.
- **Run the day.**
  - Cover chosen fairly, within each person's limit for the term, with work set for covered
    lessons.
  - The day for every member of staff, safety checks, rest-day rotas and on-call lists, and
    transport.
- **Tell people.** Everyone with new cover or timetable changes, with a ready message by email,
  Teams, calendar file, or an outbox that Power Automate can send.
- **For every school.**
  - The school's logo and colour.
  - Who can change everything, cover only, or just look.
  - A welcome screen and a demo school.
  - Help inside the app.
  - Subject access downloads and removal of old records.
  - Exports for iSAMS, and imports from TimeTabler, Excel and CSV.

## Editions

| Edition | Data kept in | Best for |
|---|---|---|
| Single file | The file itself, an Excel workbook, or a CSV folder | One timetabler, or trying it out |
| Hosted | Excel in OneDrive or SharePoint, or Google Sheets, with each person's school sign-in | Several people, using Microsoft 365 or Google Workspace |
| Power Apps | Dataverse | Several people at once with changes saved as they go, and Power Automate |

## Security and privacy

- Data goes only where the school chooses. There is no tracking or analytics.
- The single-file and hosted editions carry a content security policy, so the browser blocks every
  other connection.
- Sign-in is Microsoft's or Google's own, with delegated permissions.
- No passwords, keys or secrets are stored.
- Everything brought in is made safe.
- WCAG 2.2 AA is checked automatically in light, dark and high contrast.

## Documents

| Document | For |
|---|---|
| [docs/USER-GUIDE.md](docs/USER-GUIDE.md) | Timetablers, leaders and office staff |
| [docs/ADMIN-GUIDE.md](docs/ADMIN-GUIDE.md) | IT: choosing an edition, installing without a command line, roles, backups, updates |
| [CLOUD-SETUP.md](CLOUD-SETUP.md) | IT: hosting the app and registering it with Microsoft and Google |
| [SETUP.md](SETUP.md) | IT: the Power Apps table, security roles and publishing |
| [docs/POWER-AUTOMATE-OUTBOX.md](docs/POWER-AUTOMATE-OUTBOX.md) | Flow builders: sending the outbox |
| [docs/DATA-PROTECTION.md](docs/DATA-PROTECTION.md) | The DPO: what is held, where, security, rights, retention, DPIA answers |
| [docs/ACCESSIBILITY.md](docs/ACCESSIBILITY.md) | Accessibility statement |
| [docs/RELEASE-NOTES.md](docs/RELEASE-NOTES.md) | What changed in each version |
| [docs/AI-PROVIDERS.md](docs/AI-PROVIDERS.md) | The optional AI assistant: setting up each AI service, and adding a new one |
| [docs/AI-PRIVACY.md](docs/AI-PRIVACY.md) | The AI assistant for the DPO: what is sent, what never is, the services |
| [docs/POWER-APPS-STAFF-APP.md](docs/POWER-APPS-STAFF-APP.md) | Power Apps: the SLT build app and the staff app with lesson registers (tables, roles, set-up) |
| [docs/STAFF-VIEWER.md](docs/STAFF-VIEWER.md) | The staff Viewer: publishing a staff-safe, read-only page for staff, and getting it onto phones |
| [docs/AI-ACTION-TEMPLATES.md](docs/AI-ACTION-TEMPLATES.md) | AI action templates: the format for making and sharing AI buttons, with an example pack |
| [docs/AUDIT-REPORT.md](docs/AUDIT-REPORT.md) | The final audit: the brief point by point, what was found and fixed, and what to check before going live |

## For developers

| Command | What it does |
|---|---|
| `npm install` | Installs what the app needs |
| `npm run dev` | Runs the Power Apps version on this computer in demo mode, with data kept in the browser |
| `npm run build` | Builds the Power Apps code app into `dist/` |
| `npm run build:single` | Builds the Power Apps web resource, one file, into `dist-single/` |
| `npm run standalone` | Builds the single-file and hosted edition into `dist-standalone/` |
| `npm test` | Builds every edition and runs about 1,500 automated checks (needs Playwright with Chromium) |

| Path | What it is |
|---|---|
| `src/app.js` | The app, shared by every edition |
| `src/lib/` | Rules engine, scheduler, insights, Excel reader and writer, cloud storage |
| `src/dataverse/` | Saving to Dataverse, row by row |
| `tools/build-standalone.mjs` | Builds the single file, with its content security policy |
| `tests/` | Automated tests, including stand-ins for Dataverse, Microsoft Graph, Google Sheets and the Microsoft and Google sign-in pages |

How the data is stored: one Dataverse table, **Timetable item**. Each row is one thing (a member of
staff, a lesson, an absence, a cover choice), identified by **Item kind** and **Item key** within a
**Timetable code**. The details are JSON in **Item data**. `src/dataverse/rows.js` describes the
layout. The data model is documented in `src/app.js` (search for DATA MODEL 3.0).
