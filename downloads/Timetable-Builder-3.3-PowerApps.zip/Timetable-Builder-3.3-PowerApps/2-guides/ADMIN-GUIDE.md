# Timetable Builder: guide for IT and administrators

This guide covers:
- choosing how the school runs the Timetable Builder
- installing it
- who can change what
- backups and updates
- data protection settings

None of the main routes need a command line.

## 1. Choose an edition

There is one app, delivered in three forms. The data model and the features are the same in each.

| Edition | Where the timetable is kept | Several people at once | What IT does |
|---|---|---|---|
| **Single file** (`Timetable-builder.html`) | Inside the file, an Excel workbook, or a CSV folder, on the school's own storage | One at a time, by passing the file or workbook | Nothing. Keep the file in the school's own storage. |
| **Hosted, with Microsoft 365 or Google** | A workbook in OneDrive or a SharePoint library, or a Google Sheet | Yes. Each person signs in with their school account. Saves are checked so nobody overwrites anyone else. | Publish one file on an https address and register it with Microsoft and/or Google (about 30 minutes; see CLOUD-SETUP.md). |
| **Power Apps** (Dataverse) | The Timetable item table in your Dataverse environment | Yes, with changes saved as you go and shown to others within 30 seconds | Create one table and a security role, then upload one web resource (about an hour; see section 3). |

Things to know about each:

- **Every edition**
  - Works offline once open, apart from cloud saving.
  - Never sends data anywhere except where you keep it. There is no tracking or analytics.
- **Single file and hosted editions:** the page carries a content security policy, so it cannot
  connect anywhere else.
- **Power Apps:** the only edition that can send messages automatically, using a Power Automate
  flow (see POWER-AUTOMATE-OUTBOX.md).

## 2. Single file and hosted

**Single file.** Open `Timetable-builder.html` in Edge or Chrome. Edge and Chrome can save straight
over the file and over Excel workbooks; other browsers save a new copy to Downloads.
- **Keep in mind:** the file holds personal data when the timetable is kept inside it. Store it
  where staff files are stored, not on a personal device or a public link.
- **Shared computer:** untick **Keep unsaved work on this computer** in **Where your data is
  kept**, so nothing is left in the browser.

**Hosted.** Follow CLOUD-SETUP.md. In short:
1. Publish the app at an https address.
2. Register it with Microsoft Entra (Files.ReadWrite.All, delegated, Single-page application, no
   secret) and/or Google Cloud (Sheets API, Internal consent screen, Web client).
3. Put the IDs into the app.
4. Download the app for your web site with the IDs built in, and upload it.

The hosted file contains no timetable data.

## 3. Power Apps, without a command line (web resource)

You need:
- a Power Platform environment with Dataverse
- a maker with System Customizer (or higher) in it
- Power Apps licences for the people who open the app

1. **Create the table and the security roles.** Follow SETUP.md sections 2 and 3: one table,
   *Timetable item*, with seven columns. Then create:
   - **Timetable editor:** Create, Read, Write, Delete, Append, Append To
   - **Timetable viewer:** Read
2. **Upload the app.**
   1. Go to make.powerapps.com, then **Solutions**, and open or create your solution.
   2. Choose **New**, then **More**, then **Web resource**.
   3. Upload the Power Apps file, `Timetable-builder-PowerApps-<version>.html`. Type: **Webpage (HTML)**. Display name:
      Timetable Builder. Name: for example `timetablebuilder.html`.
   4. Save, then choose **Publish all customizations**.
3. **Make the app.**
   1. In the solution, choose **New**, then **App**, then **Model-driven app**, named Timetable
      Builder.
   2. Choose **Add page**, then **Web resource**, and pick the web resource.
   3. Save and **Publish**.
   4. Share the app with the people who need it, with the right security role.
4. **Recommended: the staff app.** POWER-APPS-STAFF-APP.md sets up a second app for staff (the
   Viewer, signed in, phone first, with lesson registers), without giving staff access to this table.
5. **Optional: a view-only staff page.** Upload the same file a second time with `staff` in its
   name, for example `timetablebuilder_staff.html`, and add it as a page. It opens straight on the
   staff day view, with nothing to edit.
6. **First run.**
   1. Open the app and press **Check setup**. It writes, reads back and deletes a test row, and
      names any column that is set up wrongly.
   2. Choose **Start a new timetable**, or bring in a timetable from the single-file edition
      (**File**, then **Bring in data from a backup**).

SETUP.md section 4 describes the Power Apps *code app* route instead. That needs Node.js and the
Power Platform command line, usually done by a partner.

## 4. Who can change what

There are three layers:

1. **Who can open the data at all.** This is the real lock:
   - for a file or workbook, its storage permissions
   - in Microsoft 365 or Google, sharing (Can edit or Can view)
   - in Power Apps, the security role
2. **Roles inside the app.** Setup, then **Who can change this timetable**:
   - **Can change everything**
   - **Cover and the day only:** the office can arrange cover without touching the timetable
   - **Can look, not change**

   People are matched by the account they sign in with: the Microsoft account, the Google
   account, or the Power Apps user's sign-in name. When the timetable is in a file on a computer,
   the app cannot tell who is using it, so these roles apply only to signed-in editions. Nobody
   can remove their own access by mistake.
3. **The staff view.** Open it from the File menu, or use the `#staff` address. It shows the day
   for everyone, with nothing to edit.

## 5. Branding and support details

- **Setup, then Your school's look:** a logo, and a colour that is adjusted automatically to keep
  text readable (WCAG 2.2 AA).
- **Support contact:** set it in **Where your data is kept**, then **Cloud sign-in (for your IT
  team)**, then **Support contact**. It appears in Help, About and privacy. It is stored with the
  hosted app's settings, not in the timetable.

## 6. Backups, updates and moving between editions

- **Backups**
  - **File, then Save a backup file of everything:** a `.json` file with everything, including
    settings, scenarios and snapshots.
  - **File, then Everything to Excel:** a workbook that can be opened again in any edition.
  - The **Getting started** list reminds people every two weeks.
- **Updates**
  - *Single file:* open your timetable in the new version with **File**, then **Bring in data
    from a backup**, or open your workbook from **Where your data is kept**.
  - *Hosted:* replace `index.html`. The data stays in Microsoft 365 or Google.
  - *Power Apps:* upload the new file over the web resource and publish. The data stays in
    Dataverse.
  - After an update, **What's new** shows once.
- **Moving between editions:** every edition can export everything to Excel, and open that
  workbook.

## 7. Data protection

DATA-PROTECTION.md lists:
- what the app holds
- where it goes
- the tools for subject access requests and for removing old records
- answers for a DPIA

## 8. Troubleshooting

| What you see | What to do |
|---|---|
| Changes are not saving (Power Apps) | Check the user's security role. Then press **Check setup** on the opening screen. |
| "Microsoft does not know this web address" | See CLOUD-SETUP.md, Troubleshooting. |
| Cloud choices say they need a web address | The app was opened as a file. Open it from its https address. |
| "Someone else has saved…" | Choose **Open their version** or **Save mine over theirs**. A copy of yours is downloaded first. |
| The welcome screen keeps appearing | It only shows for an empty timetable. Add the school day, or open your workbook. |
| Something else | In the browser's developer tools console, look for red errors and send them to your support contact. |
