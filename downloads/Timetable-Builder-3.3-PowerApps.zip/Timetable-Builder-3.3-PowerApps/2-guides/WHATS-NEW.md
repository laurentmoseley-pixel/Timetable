# What's new in the timetable apps

## For all staff: the Viewer

- **It opens on Today.** At the top: when it was last updated, then **Today's changes**: cover you are
  doing, rooms that have moved, and lessons not with you today. The reason someone is away is never shown.
- **Now and Next all day.**
  - Before school: your first lesson and when it starts.
  - In a lesson: the subject, then **Room**, **Group** and **With** (the other adults) on their own lines,
    and a bar showing the minutes left.
  - At break: the break, and what is next.
  - After school: what tomorrow starts with.
- **Find a colleague, room or group** with the box on Today: type a name and tap it.
- **Four big tabs:** Today, Week, Find and Cover.
- **Cover is easy to spot:** a **Cover** label and a bar down the side, in the day and the week.
- **Display and settings** (top right): text size, an easier-to-read font, and high contrast. Your choices
  are remembered on your device.
- **Your own link:** in Display and settings, **Copy my link** opens the Viewer straight on your timetable.
  Bookmark it, or add it to your home screen.

## For timetablers and SLT: the Builder

- **Home** is the first page. **To do** lists what needs you today, with one button each. Below it are
  the headline numbers, safety and staffing, and cover so far.
- **New names:** Build is now **Timetable**, and Scenarios is **What if**. Staff, Students and Rooms are
  **People and rooms**. Subject choices, Rest days and on call, Transport and One person are under **More**.
  Search (Ctrl K) still finds the old names.
- **Print the whole timetable:** a master sheet of every group, member of staff or room, for the whole week.
  It can be printed by site.
- **Summary of changes for all staff** (the bell): one short list of what has changed in the week, to copy
  into an email or Teams post. No pupils and no reasons for absence.
- **Blocked time:** PPA, ECT time, meetings and maintenance as part of a person's week, in Setup or by
  clicking an empty slot on People and rooms. It is never covered, and nobody is asked to cover in it.
- **Edit on People and rooms:** click a lesson on Staff, Students or Rooms to change it there, or an
  empty slot to add a lesson for just that person or room.
- **Right-click a lesson** for quick jobs: Edit, Swap, Change room, Copy, No staff needed, Lock, Delete.
- **Swap or replace a person** on one lesson, a class's lessons or all their lessons. Free people come
  first, and clashes are shown **before** you confirm.
- **Hover over a lesson** to see all of it. **Compact** or **Comfortable** sets the size of the grid.
- **An empty slot suggests** what the class usually has then, with an adult and room that are free.
- **Cover:** one button, **Cover this day**. Printing and copying are in one menu.
- **Print the meeting pack:** staffing load, cover, room use and problems, in one click.
- **New school year** (File): makes next year from a copy, moving pupils up a year.
- **Pupil Viewer** (Setup): one simple file per pupil, with only their own timetable in it.
- **Take the tour** from Home or File, Help.
