# Timetable Builder in Power Apps: setup guide

> **No command line?** Use Route A at the end of this guide, or docs/ADMIN-GUIDE.md section 3:
> upload one ready-made file as a web resource. Sections 2 and 3 (the table and permissions) apply
> to both routes. Section 4 below (the code app) needs Node.js and the Power Platform command line.

This guide is for the Power Platform admin and whoever publishes the app. Setup takes
about an hour the first time: 15 minutes for the table, 15 for permissions, and the rest
to build, publish and check.

The app is a Power Apps **code app**. It is the same Timetable Builder as the single-file
version, but it saves to Dataverse, so several people can work on the same timetable and
see each other's changes.

---

## 1. What you need

| Need | Who sorts it | Notes |
|---|---|---|
| Power Apps Premium licence (or pay-as-you-go / App Pass) | Licensing admin | Only for people who **open** the app, such as timetablers and SLT. Staff who only get Teams or email messages from Power Automate do not need one. |
| A Power Platform environment with Dataverse | Power Platform admin | Ideally two: a test environment and a live one. |
| Code apps switched on in that environment | Power Platform admin | Power Platform admin centre → **Manage** → **Environments** → choose the environment → **Settings** → **Product** → **Features** → **Power Apps code apps** → turn on **Enable code apps** → **Save**. |
| A computer with Node.js 22 or later | Publisher | From nodejs.org. Git is optional. |
| Permission to create tables and apps in the environment | Power Platform admin | Environment Maker, or System Customizer and above. |

---

## 2. Create the table

All the timetable data lives in one table. Each row is one thing: a member of staff, a
lesson, an absence or a cover choice. The details are in the Item data column. A few
details are copied into their own columns so that flows and views can use them.

1. Go to make.powerapps.com and choose the environment.
2. **Tables** → **New table** → **Start with a blank table**, or **New table** and then **Set advanced properties**, depending on what your screen shows.
3. Display name: **Timetable item**. Plural name: **Timetable items**.
4. Keep the primary column as **Name**. Its maximum length must be at least 100.
5. Save the table, then add these columns. **Type the display names exactly as shown.** Dataverse turns them into the logical names the app looks for.

| Display name | Data type | Maximum length | Logical name ends with |
|---|---|---|---|
| Item kind | Single line of text (Plain text) | 100 | `_itemkind` |
| Item key | Single line of text (Plain text) | 100 | `_itemkey` |
| Item date | Single line of text (Plain text) | 100 | `_itemdate` |
| Person code | Single line of text (Plain text) | 100 | `_personcode` |
| Person email | Single line of text (Plain text) | 200 | `_personemail` |
| Item data | Multiple lines of text (Plain text) | **1,048,576** | `_itemdata` |
| Timetable code | Single line of text (Plain text) | 100 | `_timetablecode` |

The logical name is shown under **Advanced options** when you create a column, for
example `cr4d2_itemkind`. The part before the underscore is your publisher prefix. It
does not matter what it is, but every column must use the same one.

**Item data is the one that most often goes wrong.** It must be *Multiple lines of text*
with the maximum set to 1,048,576. If it is left at the default, saving fails with "A
value is too long". The app's **Check setup** button tests for this.

Optional, but recommended: turn on **Auditing** for the table (table **Properties** →
**Advanced options**). That gives a full history of who changed what, on top of the app's
own change log.

---

## 3. Permissions

Create a security role, for example **Timetable editor**, with **Create, Read, Write,
Delete, Append and Append To** on the Timetable item table at **Organization** level.
Give it to everyone who edits timetables.

For people who should only look, give a role with **Read** only. They can open and print
timetables. If they change something, the app tells them their account is not allowed to
save, and nothing is changed for anyone else.

Every timetable in the environment is visible to everyone with access to the table.

---

## 4. Build and publish

Run these in a terminal, in the app's folder (the folder with `package.json`):

```bash
npm install
npx pa auth login
npx pa app init --environment-id <your-environment-id> --display-name "Timetable Builder"
npx pa app add data-source --connector dataverse --table <prefix>_timetableitem
npm run build
npx pa app push
```

- The environment ID is in the Power Platform admin centre, on the environment's page.
- In the `add data-source` line, use your table's logical name, for example `cr4d2_timetableitem`.
  This creates `src/generated/services/…Service.ts`. **Do not rename it or move it.** The app
  finds it by name and works out your prefix from it, so nothing needs editing.
- `npx pa app push` prints the app's link. Share the app from make.powerapps.com →
  **Apps** → **…** → **Share**, or with `npx pa app share`.

To try it on your own computer first, run `npx pa app run` and open the **Local Play** link it
prints, in the same browser profile you use for Power Apps.

---

## 5. First run

1. Open the app. It looks for the table, then lists the timetables (none yet).
2. Press **Check setup**. It writes, reads back and deletes a test row, and names any column
   that is missing or set up wrongly.
3. Press **Start a new timetable**.
4. To bring in an existing timetable from the single-file version, choose **File** →
   **Bring in data from a backup**, then pick the old `Timetable-builder.html`, or a backup
   `.json` file. Tick everything and choose **Bring in ticked parts**. A large timetable shows
   "Saving 1,200 of 2,000…" while it goes in. Leave the app open until it says
   **All changes saved**.

From then on, changes save by themselves within a second or so. The status next to Undo
says **Saving…** or **All changes saved**. If the connection drops, it says
**Not saved yet, retrying** and keeps your changes until it can save.

### More than one timetable

**File** → **Copy this timetable** makes a separate copy, for example to plan next year
without touching the live one. **File** → **Open another timetable** switches between
them, and you can delete old copies there.

### Two people at once

Each person's app checks for other people's changes every 30 seconds, and whenever the
window comes back into view. If something has changed, the timetable refreshes and a
message says so. It never refreshes while you are typing, or while your own changes are
still saving. If two people change **the same item** at the same moment, the later save
wins. Different items never overwrite each other.

---

## 6. Check these on the first publish

These all work in testing, but depend on how Power Apps hosts the app in your tenant.
Try each one once:

- **Downloads:** File → Export lessons (CSV), Save a backup file, and Export for iSAMS.
- **Printing:** Individual → Print this.
- **Uploads:** TimeTabler `.HTM` exports and CSV sheets. Excel files cannot be read inside
  Power Apps, because it does not let pages load the Excel reader from the internet. Save
  them as CSV instead.
- **Two people:** two people open the same timetable. One adds a room. The other should see
  it within 30 seconds.

---

## 7. iSAMS

Setup → **iSAMS codes and staff emails** holds the codes iSAMS uses: staff codes, pupil
IDs, subject, room and set codes, year groups and period numbers. The panel lists what is
missing. **Export for iSAMS** saves three files:

| File | What it is |
|---|---|
| `edval_timetable.csv` | One row per lesson period and teacher: Period Id, Set Code, Year level, Subject, Teacher, Room |
| `edval_classes.csv` | One row per student per set: Student Id, Course Code, Class Code, Form, Subject, Teacher |
| `…-isams-check.csv` | Everything in readable form, to check before importing |

These follow the layout that iSAMS Timetable Manager accepts from the timetabling package
Edval, as published by Tes. **Before you import into the live timetable:**

1. Ask your iSAMS administrator which import type they use. If the school currently imports
   from TimeTabler, send a copy of the files TimeTabler last exported for iSAMS. The export
   can then be matched to that layout exactly.
2. Check the period numbers against **Manage Periods & Days** in iSAMS.
3. Import as a **development timetable** first (Timetable Manager → Import → tick "Mark this
   timetable import as a development timetable"). Fix anything the automatic checks report,
   then make it live.

Staff emails are not sent to iSAMS. They are for Power Automate (below).

---

## 8. Optional: tell staff about cover with Power Automate

Every cover choice is its own row, with the covering person's email in **Person email**
and the date in **Item date**. That makes notifications straightforward.

**Flow 1: message each person when they are given cover**

1. Trigger: **Dataverse – When a row is added, modified or deleted**.
   - Change type: **Added or Modified**
   - Table name: **Timetable items**
   - Scope: **Organization**
   - Select columns: `<prefix>_personemail` (so it only fires when who is covering changes)
   - Filter rows: `<prefix>_itemkind eq 'cover' and <prefix>_personemail ne null`
2. Action: **Microsoft Teams – Post message in a chat or channel** (Flow bot → chat with
   **Person email**), or **Office 365 Outlook – Send an email (V2)** to **Person email**.
3. Message: use **Name** (for example "Cover 7B P3 Maths for Jo Bray") and **Item date**.

**Flow 2: a morning summary for each person**

1. Trigger: **Recurrence**, weekdays at 7.30.
2. **Dataverse – List rows** on Timetable items, filter
   `<prefix>_itemkind eq 'cover' and <prefix>_itemdate eq '@{formatDateTime(utcNow(),'yyyy-MM-dd')}'`.
3. Group by **Person email** and send each person their list.

Absences (`itemkind eq 'absence'`), student absences (`stuabs`) and extra-staffing
requests (`extra`) can be used the same way.

---

## 9. Updating the app later

Make the change, then run `npm run build` and `npx pa app push` again. The data stays in
Dataverse and is not touched by a new version.

To make the single-file version from the same code, run `npm run standalone`. It is
written to `dist-standalone/Timetable-builder.html`.

---

## 10. Troubleshooting

| What you see | What it means | What to do |
|---|---|---|
| "Demo mode" on the opening screen | The app could not find the generated Dataverse service | Run the `npx pa app add data-source` step, then `npm run build` and `npx pa app push` |
| "Dataverse has no column called …" | A column name does not match | Rename it, or delete and recreate it with the display name in section 2 |
| "A value is too long…" | Item data is not set to 1,048,576 characters | Change the column's maximum length |
| "Your account is not allowed…" | No security role on the table | Give the Timetable editor role (section 3) |
| "Not saved yet, retrying" for a long time | No connection to Dataverse | Changes are kept and saved when the connection returns. Do not close the app until it says All changes saved |
| "Not saving: setup problem" | One of the above | Fix it, then press **Save now** |

To troubleshoot, open the browser's developer tools console and type
`__TT_DEBUG__.host._debug()`. It shows the number of rows held, the last check time and any
error.

---

## What is where

| Path | What it is |
|---|---|
| `src/app.js` | The Timetable Builder itself, shared by both versions |
| `src/shell.html`, `src/styles.css`, `src/seed.json` | Its screens, look and starting subjects |
| `src/main.js` | Starts the Power Apps version: opening screen, timetable list, setup check |
| `src/dataverse/rows.js` | How a timetable is split into rows and put back together |
| `src/dataverse/store.js` | Saving, retrying and picking up other people's changes |
| `src/dataverse/adapter.js` | Finds the generated Dataverse service and talks to it |
| `src/dataverse/mock.js` | A stand-in table in the browser, for demo mode and testing |
| `tools/build-standalone.mjs` | Builds the single-file version |
| `tests/` | Automated tests (`npm test`; needs Playwright: `npm install --no-save playwright && npx playwright install chromium`) |

## Route A: no command line (web resource)

`npm run build:single` makes `dist-single/index.html`, one self-contained file. Upload it to
Dataverse as a web resource (Webpage (HTML)) and add it to a model-driven app as a Web
resource page. When served by Dataverse, the app talks to the Web API directly
(`src/dataverse/webapi.js`): it finds the table whose logical name ends in `_timetableitem`,
uses the signed-in user's session, and needs nothing else set up. The same file also runs as
the Claude-hosted demo (shared store) and, opened on its own, in browser-only demo mode.
Tests: `node tests/webresource.test.cjs dist-single/index.html` (stand-in Web API).
