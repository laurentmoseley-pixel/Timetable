# Timetable Builder: data protection information

This is for the school's data protection officer (DPO) and whoever completes the school's data
protection impact assessment (DPIA). The school is the data controller. The Timetable Builder is
software the school runs. Its supplier does not receive, see or host any of the school's data.

## What the app holds

| About | What | Why |
|---|---|---|
| Staff | Name, code, roles, subjects and specialisms, working days and rest days, maximum periods, cover limits, driving licence category, work email address, optional MIS code | To timetable lessons, arrange cover fairly, and tell people about changes |
| Staff absence | Dates, which periods, type (for example Illness, Training, Trip), optional reason | To arrange cover. Illness is health information, a special category of personal data: keep reasons brief or leave them blank. |
| Cover and duties | Who covered what, when; work set; swaps; calls in from rest days; on-call turns | To run the day and share cover fairly |
| Pupils | Name, code, year group, groups and sets, key adult, optional MIS code, who must be kept apart | To timetable lessons and keep them safe |
| Pupil absence (optional) | Dates and an optional reason | So staffing ratios use the pupils actually in. The MIS remains the register of attendance. |
| Transport | Vehicles, journeys, drivers and passengers | To book school transport |
| Messages | Messages to staff about their cover and timetable, and who has been told what | To tell people about changes |
| Change log | What changed, when, and the name entered on the device (or the signed-in user) | Accountability |

The app does not need dates of birth, addresses, contact details for pupils or parents, medical
details, or SEN information. It holds none of these unless someone types them into a free-text
field.

## Where it is kept

The school chooses this in **File**, then **Where your data is kept**, and the app shows the choice
in the header at all times.

| Choice | Location | Who else processes it |
|---|---|---|
| Inside the file, an Excel workbook, or a CSV folder | Wherever the school saves the file | Nobody |
| Microsoft 365 | The school's OneDrive or SharePoint | Microsoft, under the school's existing Microsoft agreement |
| Google Sheets | The school's Google Drive | Google, under the school's existing Google Workspace agreement |
| Power Apps | The school's Dataverse environment | Microsoft, under the school's existing Microsoft agreement |

## The staff Viewer

The Viewer (STAFF-VIEWER.md) is a read-only page for staff, holding a **staff-safe copy** that the
school publishes. The copy holds:
- staff names
- each lesson's group, subject, room and staff
- each published day's cover and duties
- if the school chooses, who is away (names only)

It never holds pupils, emails, pupil numbers, absence reasons or types, notes or notices. A pupil's
name in any text is replaced with "a pupil". Who can open a copy depends on where the school puts it,
so keep it where only staff can reach it. The Viewer sends nothing anywhere. On each device it keeps
only who the person is and what they last saw.

## The pupil Viewer

Each pupil Viewer file holds one pupil's first name and their own lessons (subject, room, the adults'
names and initials, and who is covering). It holds no other pupil's data, no staff codes, emails or
notes, and no reasons for absence. It sends nothing anywhere and allows no connections. On the device it
remembers only the text size and font chosen.

**Adult photos are optional and are new personal data.** If you add them, they are kept with the
timetable as small pictures (120 pixels) and go only into the Viewers of pupils that adult works with.
Ask each adult first, record the purpose (helping pupils recognise their adult), and remove a photo
when the adult leaves or asks. Give each file only to its own pupil.

## The staff app and lesson registers (Power Apps)

In the Power Apps edition (POWER-APPS-STAFF-APP.md) there are two more tables:

- **Timetable published** holds the staff-safe copy. For registers it also holds:
  - each group's pupil list (names)
  - which pupils are reported off (no reasons)
  - a one-way code of each staff email, so the app knows who is signed in without holding emails

  Staff can read it. It is replaced at each update.
- **Timetable register** holds lesson registers:
  - date, group and period
  - the staff code of who took it
  - each pupil's code and mark (Present, Late, Absent, Out of lesson)

  It holds no names, reasons or notes. Staff can add registers and correct their own. Leaders can
  read them all.

Staff have no access to the Timetable item table. Agree a retention period for registers with your
DPO and set a bulk delete job (POWER-APPS-STAFF-APP.md). Lesson registers are for internal
monitoring; the MIS remains the statutory attendance register.

## Security measures

- **Nowhere else.**
  - The app sends data only to the place the school chose.
  - There is no tracking, analytics, advertising or telemetry.
  - The single-file and hosted editions carry a content security policy. The browser itself
    blocks connections to anywhere except Microsoft sign-in and Microsoft 365, Google Sheets, and
    the app's own web address.
- **Sign-in.**
  - Cloud editions use each person's own school account, through Microsoft's MSAL library and
    Google's own sign-in page.
  - Microsoft access is *delegated*: a person reaches only files they could already open.
  - No passwords, keys, client secrets or flow addresses are stored in the app or the timetable.
  - Sign-in tokens stay in the browser tab.
- **Access.**
  - Storage permissions or the Dataverse security role decide who can open the data.
  - Inside the app, roles decide who can change everything, only cover and the day, or only look.
  - The staff view has nothing to edit.
- **Imports are made safe.**
  - Everything brought in is cleaned of control characters and of keys that could change how the
    app behaves. This includes rows written straight into Dataverse by another tool.
  - Text is always shown as text, never run.
  - Spreadsheet exports cannot carry formulas.
  - Google Sheets are written as plain values.
- **Accountability.** Changes are recorded in the change log. Dataverse auditing can be turned on
  for a full history.
- **Backups.** The app reminds people to save a backup every two weeks. Backups hold personal data:
  store them as you store other staff records.

## Rights of the people concerned

- **Subject access.** Setup, then **Personal data**, then **Everything about one person**,
  downloads all the timetable holds about a member of staff or a pupil, as JSON or a spreadsheet.
  This covers:
  - their record, lessons and groups
  - absences, cover done and received, swaps and rest-day changes
  - journeys and messages
  - what they have been told
  - every change log entry that names them
  - scenarios that include them

  The download is recorded in the change log.
- **Correction.** Edit the person in Setup. Changes follow everywhere the person appears.
- **Erasure.** Removing a person in Setup removes them from lessons, cover, rotas, messages and
  lists. Their past cover entries go too.

## Keeping records only as long as needed

Setup, then **Personal data**, then **Remove old records**, deletes day-to-day records from before
a date you choose:
- staff and pupil absences
- cover choices and work
- extra-staffing requests, swaps and rest-day changes
- one-off journeys
- outbox messages
- records of who was told
- change log entries

A backup is downloaded first, and the removal is recorded in the change log. Staff, pupils, groups
and lessons are not touched.

A common choice is to keep the current and previous school year. Agree the period with your DPO
and set it in your retention schedule.

## For the DPIA

- **Personal data of children?** Yes: pupils' names, groups, timetables, and who must be kept
  apart.
- **Special category data?** Only if staff absence types or free-text reasons describe health.
  Use the type field and keep reasons brief.
- **Automated decisions?** Cover suggestions and the automatic timetable are proposals. People
  review and can change every choice before it is used. Nothing has a legal or similarly
  significant effect on anyone.
- **International transfers?** Only through the school's own Microsoft or Google tenancy, under the
  school's existing terms.
- **Supplier access?** None. The supplier does not host the app or the data.
