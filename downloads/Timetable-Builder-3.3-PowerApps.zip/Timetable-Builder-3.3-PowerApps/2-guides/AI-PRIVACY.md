# The AI assistant: privacy summary for the DPO

This summary supports the school's data protection impact assessment (DPIA) for the optional AI
assistant. It adds to DATA-PROTECTION.md. The AI assistant is off unless the school turns it on.

## What it does

When someone who can change everything uses an AI action, the app sends a description of the
timetable's structure to an AI service the school has chosen. The service returns a suggestion,
which the app checks. Nothing changes until a person approves it.

## What is sent, and what never is

Each action declares the data it needs, from this list. The gateway builds nothing else.

| Scope | What goes |
|---|---|
| school | Day names, period numbers and times |
| subjects | Subject codes; standard subject names (Maths, English…) keep their names, anything else is a code |
| staff | Staff as codes (S1…), with role types from the app's fixed list, subjects they teach, working days, weekly limits |
| groups | Groups as codes (G1…), with size, adult ratio, team (codes) and weekly plan |
| rooms | Rooms as codes (R1…), with capacity and standard room type |
| lessons | Each lesson: group, day, period, subject, staff, room (all codes), length, locked |
| problems | Rule problems from the Checks, in codes |
| absences | Who is away on one day and which periods (codes, no reasons) |
| pupils | Pupils as codes (P1…) and their groups, only for actions that truly need it |
| cover | For one day's absence: each lesson needing cover (period, group, subject, as codes), who is free for it (codes), how much cover each has done this term and today, and the daily cover limit |
| columns | For a spreadsheet the app cannot read: the column headings and the kind of values in each ("a day name", "a number", "short codes"), never the values themselves |

**Never sent:** names, email addresses, the school's own staff codes and pupil numbers, group and
room names, lesson titles, absence reasons, notes, notices, cover work, the change log, or any other
free text.

**Checks:** the codes are shuffled afresh for every action, so they cannot be matched between
actions. (When the app sends a proposal back to the AI to put right, up to five times, those retries
use the same codes, so the AI can understand what went wrong.) Before anything is sent, the whole request is scanned for every name, email, code and note
in the timetable. If any is found, nothing is sent and the attempt is logged as blocked. Editors can
choose to see each request in full before it goes; this is on by default.

## What each action sends

| Action | Data scopes |
|---|---|
| Fix all clashes | school, subjects, staff, groups, rooms, lessons, problems |
| Timetable this class | school, subjects, staff, groups, rooms, lessons |
| Find cover | cover, staff, subjects, groups |
| Balance this week | school, subjects, staff, groups, rooms, lessons |
| Explain this placement | school, subjects, staff, groups, rooms, lessons, problems |
| Run a what-if | school, subjects, staff, groups, rooms, lessons, and the question, with any person, group or room in it replaced by its code (typed names are refused) |
| Map my spreadsheet | columns only |

No official action sends pupil-level data.

**Custom actions** (made by the school in Setup, AI actions) use the same gateway and the same list of
data; they cannot add anything to it. The builder warns when an action would send pupils (as codes),
so the school can record it here. A prompt containing a whole name, staff code or email cannot be
saved, and prompts are checked again on every request. **Practice runs** send a made-up school (the
demo), never the school's own data. **Action packs** (files for sharing actions) hold templates only:
no timetable data, no history and no names. Every request and answer, and every retry, is in the AI
log.

## Is it still personal data?

Yes, potentially. Codes replace names (pseudonymisation), but the school holds the key to the codes
during the request, and patterns such as a staff member's working days could relate to a person.
Under UK GDPR, pseudonymised data is still personal data. The risk is low, because:
- nothing sent names or directly identifies anyone, and codes change every time
- by default no pupil-level data is sent: only group sizes
- only editors can use it, and every request is logged

**Lawful basis:** usually public task or legitimate interests (the school's timetabling and staffing
duties), as for the timetable itself. No special category data is sent.

## The service the school chooses

| Option | Where data goes | Notes for the DPIA |
|---|---|---|
| Local model (Ollama) | A computer in school | Nothing leaves the building. Lowest risk. |
| Azure OpenAI, UK South | Microsoft, in the UK, under the school's Microsoft agreement | Not used for training. |
| Claude (Anthropic) or OpenAI | The provider, usually in the US | API data is not used for training by default; zero retention can be requested. International transfer: rely on the UK Extension to the EU–US Data Privacy Framework or standard contractual clauses (IDTA); check the provider's current terms. |
| Google Gemini | Google | Use a paid project only (free-tier data may be used to improve products). |
| The school's relay | Wherever the relay sends it | The relay is the school's processor arrangement; document it. |

## Security

- **The key.** Kept in memory for the session, or encrypted on one computer with a passphrase
  (AES-GCM, key derived with PBKDF2, 310,000 rounds). Never in the timetable, the file or the
  settings.
- **Where the app may connect.** The app's security policy blocks every AI service unless the school
  downloads an AI-enabled copy for one chosen service.
- **Answers are untrusted.** They must match a strict format, are checked again by the app's rules,
  and are shown as text, never run. A person approves every change, and Undo works.

## Rights and retention

- The AI log keeps the latest 80 requests and answers, in codes, with the timetable. Because it holds
  no names, a subject access search (Setup, Personal data) does not find it. The full log can be
  downloaded from Setup, AI assistant.
- Providers keep API data for their own retention period (often up to 30 days for abuse
  monitoring) unless zero retention is agreed.

## Recommended settings

1. Start with a local model or Azure OpenAI in UK South.
2. Keep "Show me exactly what is sent" on until staff are confident.
3. Give AI access only to the timetabler and the deputy who arranges cover.
4. Review the AI log each term.
