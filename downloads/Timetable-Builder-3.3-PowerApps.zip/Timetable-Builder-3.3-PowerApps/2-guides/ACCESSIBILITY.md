# Timetable Builder: accessibility statement

The Timetable Builder aims to meet the Web Content Accessibility Guidelines (WCAG) 2.2 at level AA.
This statement covers version 3.0 in all editions: single file, hosted, and Power Apps.

## What we check automatically, on every version

- **WCAG rules.** axe-core 4.10, the industry rule set, checks every page and the main windows
  against WCAG 2.0, 2.1 and 2.2 at A and AA, in all three appearances. Version 3.0 has no failures.
  This includes keyboard access to every scrolling area and a name for every field.
- **Contrast.** Every piece of visible text on every page meets the AA contrast ratio, in all three
  appearances (light, dark and high contrast). The same check covers the windows, the welcome
  screen, Help, Insights and Scenarios. A school's own colour is darkened or lightened automatically
  until it passes.
- **Touch.** On a phone, every control on screen is at least 44 by 44 CSS pixels, and no page
  scrolls sideways.
- **Motion.** Window animations stop when the computer asks for reduced motion.

## How it works for different people

- **Keyboard.** Everything can be reached with the keyboard:
  - **Ctrl K** opens search, to reach any page, person or job.
  - **Arrow keys** move around the timetable.
  - **Alt and the arrow keys** move a lesson, as an alternative to dragging.
  - **?** lists the shortcuts.
  - Focus is always visible.
- **Screen readers.** Buttons and fields have names, icons are hidden from screen readers, windows
  are labelled dialogs, and messages are announced as they appear. Colour is never the only sign of
  anything: problems, better or worse, and over-limit all have words or symbols too.
- **Reading.** An easier-to-read font (Atkinson Hyperlegible) can be turned on in the File menu.
- **The Future look (trial).** Checked the same way, in dark and light: every text passes AA even
  against the lightest part of any glass or gradient behind it, including with a school's own
  colour. It has no failures under axe-core. **Reduce effects** turns off blur, glow and motion; the
  computer's reduced motion and reduced transparency settings are respected, and High contrast and
  Windows forced colours always use the plain style.
  High contrast can be chosen, and Windows high-contrast colours are respected. Plain English is
  used throughout.
- **Visual timetables.** Individual timetables can be printed with picture symbols for pupils who
  use them.

## Known limitations

- The Build page is a large grid of small text. Use zoom, high contrast or the easier-to-read font,
  or use the Individual page, which shows one timetable at a time.
- Dragging lessons needs a mouse or touch. The keyboard alternative is **Alt and the arrow keys**,
  or the **Where it fits** list in the lesson editor.
- Charts on the Insights page are drawn as tables with bars and shaded cells. Each has the same
  numbers as text, and a spreadsheet download.

## Feedback

If something is hard to use, tell the support contact shown in **Help**, then **About and privacy**.

This statement was prepared on 26 October 2026, based on automated checks and manual review. It
has not yet been audited by a third party.
