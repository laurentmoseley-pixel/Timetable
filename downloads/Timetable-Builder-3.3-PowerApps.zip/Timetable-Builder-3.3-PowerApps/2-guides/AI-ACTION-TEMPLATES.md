# AI action templates: the format, with examples

Every AI button in the Timetable Builder is a **template**: a small piece of data that says where the
button goes, what data it may send, what it asks the AI and how the app checks the answer. The seven
official actions are templates too. You make your own in **Setup, AI actions**, with a form, with no
code. This guide describes the format for anyone who wants to understand it, write packs by hand or
review one before bringing it in.

The AI assistant itself is described in AI-PROVIDERS.md (connecting a service) and AI-PRIVACY.md (what
is sent). Nothing in a template can get round the privacy gateway or the app's checks: a template
only chooses from what the app allows.

## How an action runs

1. A person presses the button. If the prompt has `{{question}}`, they are asked what to do first.
2. The **privacy gateway** builds the data the template asks for, as codes, fills the placeholders,
   checks the whole request for names, emails, staff codes and notes, and sends it to the school's
   chosen AI service.
3. The answer must match the **answer format** for the template's kind exactly. If it does not, the
   AI is asked once more, then the action stops.
4. The app **checks** the answer with its own rules. If it fails, the reasons go back to the AI to try
   again, up to the template's number of attempts (5 at most). Then it stops and nothing changes.
5. A person sees before and after and chooses Approve, Edit or Reject. Approving is one change, so
   Undo puts it back. Explanations change nothing.

## The fields

| Field | What it is | Rules |
|---|---|---|
| `name` | The action's name, in the library and the AI log | Required; plain text; up to 60 characters |
| `label` | The text on the button | Required; plain text; up to 28 characters |
| `icon` | The button's icon | One of `sparkle` `wand` `calendar` `clock` `people` `person` `room` `question` `balance` `list` `shield` `swap` |
| `description` | What it is for, shown on the button and in the review | Plain text; up to 200 characters |
| `kind` | What it does, which decides the answer format and the checks | `lessonMoves`, `cover`, `explain` or `columnMap` (below) |
| `place` | Where the button goes | See *Places and placeholders*; must suit the kind |
| `scope` | The data it may send | A list from *Data*; the data its kind needs is always added |
| `prompt` | What the AI should do, with `{{placeholders}}` | 20 to 4,000 characters; no keys, emails or names |
| `checks` | Extra checks, on top of the ones its kind always has | `onlyTarget`, `progress` (below) |
| `maxAttempts` | How many proposals the AI may make before the action stops | 1 to 5 |
| `version` | Goes up by one each time it is saved | Set by the app |

The app adds the rest itself: the standard instructions (the same for every action, written to work
on any AI service) and the answer format for the kind. Custom templates cannot change either. A
template can never call itself official, use an official action's id, or switch off the checks its
kind needs.

## Kinds

| Kind | What it does | Can go on | Data always sent | Checks always on |
|---|---|---|---|---|
| `lessonMoves` | Moves lessons (to another day, period, room or staff) and adds new ones | Build toolbar, a group, a member of staff, the lesson editor, the open scenario, someone who is off | `school`, `lessons` | Every lesson, day, period, room and person must exist; locked lessons never move; the whole timetable with the proposal in it must break no rule it did not already break |
| `cover` | Chooses who covers each lesson of an absence | Cover, someone who is off | `cover` | Everyone chosen must be free, do cover, not be doubled, and stay within the day's cover limit |
| `explain` | Explains, in a summary and up to 8 points; changes nothing | Anywhere except Upload sheets | (none) | (none: nothing changes) |
| `columnMap` | Matches a spreadsheet's columns to what the app needs | Upload sheets | `columns` (only) | Day, period and class matched, each field once, and the sheet must then read cleanly |

**Optional checks** (`lessonMoves` only):
- `onlyTarget`: only the lessons of this group, person or lesson may change. Needs a button on a
  group, a member of staff, the lesson editor or someone who is off.
- `progress`: it must leave fewer rule problems than it found. Needs `problems` in the data.

## Places and placeholders

Placeholders are filled in by the app, as codes, when the button is pressed.

| Place (`place`) | Where the button appears | Placeholders it fills |
|---|---|---|
| `build.toolbar` | Build, on the toolbar | (only the two below) |
| `group` | Auto build, on each group | `{{group_code}}` |
| `absence` | Cover, next to each person who is off | `{{staff_code}}` `{{date}}` `{{weekday}}` |
| `staffTimetable` | Individual, on a member of staff's timetable | `{{staff_code}}` |
| `lesson` | Build, in the lesson editor | `{{lesson_code}}` |
| `scenario` | Scenarios, only while a scenario is open | (only the two below) |
| `import` | Upload sheets, when a lessons sheet is not recognised | (only the two below) |

Everywhere:
- `{{constraints}}`: the school's hard rules and preferences in words. Add it to any action that moves
  lessons; it helps the AI succeed first time.
- `{{question}}`: what the person types when they press the button. On Scenarios it comes from the
  what-if box; anywhere else the app asks. People, groups and rooms chosen from the list go as codes.
  A typed name is refused, not sent.

**References.** In a prompt, `@[Name]` stands for a person, group, room or subject in your school,
and is sent as its code. The builder's list inserts them. They only make sense in your own school, so
avoid them in actions you share.

## Data

The template chooses what the gateway may send, from this list. Everything is codes: `S` staff, `G`
groups, `R` rooms, `Su` subjects, `L` lessons, `P` pupils, `N` cover needs, `C` columns. The codes
are different for every action.

| `scope` | What goes |
|---|---|
| `school` | Days, periods and their times |
| `subjects` | Subjects (standard subject names; any other subject as a code) |
| `staff` | Staff as codes, with roles, subjects they teach, working days and limits |
| `groups` | Groups as codes, with size, adult ratio and weekly plan |
| `rooms` | Rooms as codes |
| `lessons` | Every lesson: group, day, period, subject, staff, room (all codes) |
| `problems` | Rule problems from the Checks, in codes |
| `absences` | Who is away on the chosen day and which periods (no reasons) |
| `cover` | For one day: lessons needing cover and which staff are free for each (Cover only) |
| `columns` | A spreadsheet's column headings and the kind of values in each, never the values (Upload sheets only) |
| `pupils` | Pupils as codes and their groups (only when an action truly needs it; record it in your DPIA) |

Never sent, whatever the template says: names, emails, the school's own staff codes and pupil numbers,
group and room names, lesson titles, absence reasons, notes or anything else typed as free text.

## Answer formats

The AI must reply with JSON in exactly this shape. The app checks it, and refuses codes that were not
in the data. Days count from 0 (the first school day); periods count teaching periods from 1.

**`lessonMoves`**
```json
{ "changes": [ { "lesson": "L12", "day": 2, "period": 3, "room": "R4", "staff": ["S7"] } ],
  "adds":    [ { "group": "G3", "subject": "Su5", "day": 0, "period": 1, "length": 2, "room": "R2", "staff": ["S1"] } ],
  "notes": "Why, in a sentence or two." }
```
`room` and `staff` in a change are optional (leave them out to keep what is there). `length` 2 is a
double.

**`cover`**
```json
{ "assignments": [ { "need": "N1", "staff": "S4" } ], "unfilled": ["N3"], "notes": "…" }
```

**`explain`**
```json
{ "summary": "…", "points": ["…", "…"] }
```

**`columnMap`**
```json
{ "columns": [ { "column": "C1", "field": "day" }, { "column": "C2", "field": "period" } ], "notes": "…" }
```
Fields: `day` `period` `class` `subjectCode` `subject` `title` `room` `staffCodes` `staff`
`studentCodes` `students` `block` `ignore`.

## Writing a prompt that works on any AI service

- Say what to do with the data, in plain words: "Move…", "Choose…", "Explain…".
- Refer to the data by its names: `changes`, `adds`, `cover.needs`, `problems`, `coversThisTerm`.
- Say what *not* to do: "Only move {{group_code}}'s lessons", "leave adds empty", "move as few as
  possible".
- Add `{{constraints}}` to anything that moves lessons.
- Say what to do if it cannot be done: "change nothing and say why in notes".
- Do not name an AI service or use one service's special wording. The builder warns if you do.
- Do not type names. A whole name, staff code or email cannot be saved. If a word in your prompt is
  also part of someone's name in your school (for example "will", "may", "grace"), the builder asks
  you to confirm it is an ordinary word there. That confirmation is kept with the action in your
  timetable only, never in a pack.

## Versions

Each save is a new version, numbered. The last 10 earlier versions are kept with the timetable, with
when they were saved and by whom. In the builder, **Earlier versions** loads one back into the form;
saving it makes it the newest version. Deleting an action deletes its versions; Undo brings them
back.

## Packs

A pack is a JSON file of actions to share with another school or keep as a backup. **Save your actions
as a pack** saves them all; **Share** on one action saves just that one.

```json
{
  "format": "tt-ai-actions-1",
  "name": "Example AI actions",
  "exported": "2026-10-28",
  "app": "Timetable Builder 3.2.0-preview.3",
  "actions": [ { "version": 1, "name": "…", "label": "…", "icon": "calendar", "place": "group",
                 "kind": "lessonMoves", "description": "…", "scope": ["school", "lessons"],
                 "prompt": "…", "checks": ["valid", "hardRules", "onlyTarget"], "maxAttempts": 5,
                 "id": "", "official": false } ]
}
```

A pack holds the current version of each action only: no history, no names of who saved it, no
confirmed words and no timetable data.

**Bringing one in** (Setup, AI actions, Bring in an action pack):
- Every action goes through the same cleaning as one made in the form. Unknown fields are ignored;
  text is made plain; the place, kind, data and checks must be ones the app knows and must fit
  together.
- An action with a key, an email address, or a name, staff code or email from *your* timetable in its
  prompt is not brought in. You are told which and why.
- An action that says it is official comes in as custom. None can take an official action's id.
- Actions brought in are **switched off** until you have looked at them. Open each, choose **Try it on
  practice data**, then tick **On**.
- Up to 50 actions, and 500 KB, per pack.

## Practice data

**Preview what it sends** builds the request from a made-up school (the demo school) and shows it;
nothing is sent. **Try it on practice data** runs the action on that made-up school: the same gateway,
the same checks and the same review, marked *Practice run*, with nothing to approve. Your timetable is
not touched, and the AI never sees it. The prompt's own words are still checked against your real
timetable before anything is sent. Practice runs are recorded in the AI log, marked "(practice)".

## Examples

`docs/examples/ai-action-pack-example.json` is a pack of six example custom actions. Bring it in to
try them:

| Action | Kind | Place | Shows how to |
|---|---|---|---|
| Spread PE across the week | lessonMoves | group | limit an action to one group (`onlyTarget`) |
| Find a better slot for this lesson | lessonMoves | lesson | move just one lesson, or explain why not |
| Fix the worst problem first | lessonMoves | Build toolbar | use the rule problems, and insist on progress |
| Cover with one person where possible | cover | someone who is off | change how cover is chosen |
| Summarise a teacher's week | explain | a member of staff | explain, changing nothing |
| Ask about a group | explain | a group | take a typed question |

One in full:

```json
{
  "name": "Spread PE across the week",
  "label": "Spread PE",
  "icon": "calendar",
  "kind": "lessonMoves",
  "place": "group",
  "description": "Moves a group's PE so no two lessons fall on the same day.",
  "scope": ["school", "subjects", "staff", "groups", "rooms", "lessons"],
  "checks": ["onlyTarget"],
  "maxAttempts": 5,
  "prompt": "Look at group {{group_code}}'s PE lessons (subject PE). Move them (changes) so that no two fall on the same day and none is in the period straight after lunch. Only move {{group_code}}'s lessons, move as few as possible, and leave adds empty.\n{{constraints}}"
}
```

## The official actions

These are built in and locked. You can view each, switch it off, or duplicate it to make your own
version.

| Action | Kind | Place | Data | Extra checks |
|---|---|---|---|---|
| Fix all clashes | lessonMoves | Build toolbar | school, subjects, staff, groups, rooms, lessons, problems | progress |
| Timetable this class | lessonMoves | a group | school, subjects, staff, groups, rooms, lessons | onlyTarget |
| Find cover | cover | someone who is off | cover, staff, subjects, groups | — |
| Balance this week | lessonMoves | a member of staff | school, subjects, staff, groups, rooms, lessons | onlyTarget |
| Explain this placement | explain | the lesson editor | school, subjects, staff, groups, rooms, lessons, problems | — |
| Run a what-if | lessonMoves | the open scenario | school, subjects, staff, groups, rooms, lessons | — |
| Map my spreadsheet | columnMap | Upload sheets | columns | — |

## For developers

The template rules live in `src/lib/ai-actions.js` (`TTAIActions`): `OFFICIAL`, `KIND_RULES`,
`PLACE_VARS`, `PLACEHOLDERS`, `CHECKS`, `cleanTemplate`, `runnable`, `makePack` and `readPack`. A new
kind needs an answer format in `SCHEMAS`, rules in `KIND_RULES`, and a checker and review in the app
(`aiCheckMoves`, `aiCheckCover`, `aiCheckColumns`). A new place needs an entry in `PLACES` and
`PLACE_VARS`, and an `aiBtns('<place>', context)` call where the button should appear. Tests:
`tests/unit/ai-actions.test.mjs` and `tests/ai-library.test.cjs`.
