# Power Apps: the SLT build app and the staff app (with lesson registers)

This guide sets up two apps in your Power Apps environment:

| App | Who uses it | What it is |
|---|---|---|
| **Timetable Builder** (the SLT build app) | Timetablers and senior leaders | The full Timetable Builder: it builds the timetable, arranges cover and runs the day. It keeps the staff app up to date by itself, and its Today page shows **Lesson registers**. |
| **Timetable Viewer** (the staff app) | All staff, on a phone or a computer | Each person's day, with what is on now and next, their week, cover, rooms and groups. Its one job besides showing is **Take register** on the lessons they teach or cover. |

Any app you already have in the environment is left alone. Nothing here changes or deletes your
existing tables. If your existing app *is* the Timetable Builder, you only replace its file (step 1).

None of this needs a command line. It is all done at make.powerapps.com in a browser, by someone
with the System Customizer or System Administrator role. Allow about 45 minutes.

## How the data is kept apart

```
Timetable Builder (SLT)  ──writes──►  Timetable item       (everything; SLT only)
        │
        └──writes a staff-safe copy──►  Timetable published  (staff can read)
                                                │
Timetable Viewer (staff)  ◄──reads──────────────┘
        │
        └──saves registers──►  Timetable register   (staff add their own)
                                        │
Timetable Builder, Today  ◄──reads──────┘
```

Staff never need any access to the **Timetable item** table, which holds everything, including
pupil details, absence reasons and notes. Their app reads only the staff copy. The copy holds:

- the timetable
- each published day, with its cover and duties
- each group's pupil list (names), for registers
- which pupils the office has reported off, with no reasons

It never holds emails, pupil numbers, reasons for absence, notes or notices. Staff are recognised by
a one-way code of their email, which cannot be turned back into the email.

## Before you start

- **Licences.** Everyone who opens a model-driven app that uses Dataverse needs a Power Apps
  licence that includes Dataverse, such as Power Apps Premium, a per-app licence or
  pay-as-you-go. The Power Apps rights that come with Microsoft 365 (including A3 and A5) do not
  include Dataverse. Check this with whoever handles your Microsoft licensing before giving the staff
  app to every member of staff. If licences for all staff are not possible, the file Viewer
  (STAFF-VIEWER.md) needs none, but it has no registers.
- **The Timetable item table** is already set up (SETUP.md section 2), and the Timetable Builder
  works in your environment.
- **Staff emails.** In the Timetable Builder, **Setup, Staff**, each person's email must be the one
  they sign in to Microsoft 365 with. That is how the staff app knows who is who.

## 1. The SLT build app: update its file

1. Go to make.powerapps.com, choose your environment, then **Solutions**, and open the solution that
   holds the Timetable Builder web resource.
2. Open the web resource (for example `timetablebuilder.html`) and choose **Upload file**. Pick
   `Timetable-builder-PowerApps-3.3.html` from this package. Choose **Save**, then **Publish**.

   If you do not have the Timetable Builder in Power Apps yet, follow ADMIN-GUIDE.md section 3 first.

## 2. Create the Timetable published table

1. **Tables**, then **New table**, then **Start with a blank table** (or **Set advanced properties**).
2. Display name: **Timetable published**. Plural name: **Timetable published copies**.
3. Keep the primary column as **Name**.
4. Save, then add these columns. Type the display names exactly as shown. Dataverse makes the
   logical names from them.

| Display name | Data type | Maximum length | Logical name ends with |
|---|---|---|---|
| Timetable code | Single line of text (Plain text) | 100 | `_timetablecode` |
| Part | Single line of text (Plain text) | 100 | `_part` |
| Published data | Multiple lines of text (Plain text) | **1,048,576** | `_publisheddata` |

## 3. Create the Timetable register table

1. **Tables**, then **New table**, as before.
2. Display name: **Timetable register**. Plural name: **Timetable registers**.
3. Keep the primary column as **Name**.
4. Add these columns:

| Display name | Data type | Maximum length | Logical name ends with |
|---|---|---|---|
| Register key | Single line of text (Plain text) | 200 | `_registerkey` |
| Register date | Single line of text (Plain text) | 100 | `_registerdate` |
| Group name | Single line of text (Plain text) | 100 | `_groupname` |
| Period | Single line of text (Plain text) | 100 | `_period` |
| Taken by | Single line of text (Plain text) | 100 | `_takenby` |
| Marks | Multiple lines of text (Plain text) | **1,048,576** | `_marks` |
| Timetable code | Single line of text (Plain text) | 100 | `_timetablecode` |

All three tables must use the same publisher prefix (the part before the underscore, for example
`cr4d2_`). They will if you make them in the same solution.

**The Multiple lines of text columns must have their maximum raised to 1,048,576.** If they are left
at the default, publishing or saving a register fails. The Builder's **Check the staff app tables**
button spots this.

## 4. Security roles

**Timetable editor** (the SLT role you already have): open it, then on the **Custom Entities** tab give it:

| Table | Create | Read | Write | Delete |
|---|---|---|---|---|
| Timetable item (already set) | Organization | Organization | Organization | Organization |
| Timetable published | Organization | Organization | Organization | Organization |
| Timetable register | Organization | Organization | Organization | Organization |

**Timetable staff** (new): **Security roles**, **New role**, named Timetable staff:

| Table | Create | Read | Write | Delete |
|---|---|---|---|---|
| Timetable item | none | **none** | none | none |
| Timetable published | none | Organization | none | none |
| Timetable register | User | Organization | User | none |

These permissions mean staff can:
- read the staff copy, but not change it
- add registers
- correct only the registers they took themselves
- see that a colleague has already taken a register, so that two adults in a lesson do not both take it

Give staff the **Basic User** role as well. Power Apps needs it to open any model-driven app.

## 5. The staff app

1. In your solution: **New**, **More**, **Web resource**. Upload `Timetable-Viewer-3.3.html`. Type:
   **Webpage (HTML)**. Display name: **Timetable Viewer**. Name: for example `timetableviewer.html`.
   **Save**, then **Publish**.
2. **New**, **App**, **Model-driven app**, named **Timetable Viewer**.
3. **Add page**, **Web resource**, pick Timetable Viewer. In the navigation, remove anything else so
   it opens straight on the Viewer. **Save** and **Publish**.
4. **Share** the app with staff, giving them the **Timetable staff** role (and Basic User).

Staff can open it in a browser, or in the **Power Apps** app on their phone. It is designed for phones
first.

## 6. First run

1. Open the **Timetable Builder** app. Go to **Setup, Staff viewer**.
2. Choose **Check the staff app tables**. It should say both tables are there. If not, it says which
   column to fix.
3. Choose **Update the staff app now**. From then on, **Keep the staff app up to date by itself** does
   it within a minute of any change, and again each morning, as long as someone has the Builder open.
   Tick there what staff may see: anyone's timetable, rooms, groups, the cover board, and who is away.
4. Open the **Timetable Viewer** app as a member of staff. It shows their name and their day straight
   away.

## Lesson registers

**For staff.** In the staff app, each lesson or cover they have today shows **Take register**, from 5
minutes before it starts.
- Each pupil is marked **Present**, **Late**, **Absent** or **Out of lesson**. Pupils the office has
  reported off are already marked Absent and labelled *Reported off*.
- **Everyone else present** marks the rest in one go.
- It can be saved once everyone is marked. Afterwards the lesson shows **✓ Register** and the time.
  Opening it again lets them correct it.

**For leaders.** In the Timetable Builder, **Today**, the **Lesson registers** card shows each group in
each period of the chosen day:
- who should take the register
- who took it, and when
- how many pupils were present, late, absent and out of lesson

Registers still missing are flagged once the period is over. **Download as a spreadsheet (CSV)** gives
every pupil's mark, with names.

**What a register row holds:** the date, group, period, the staff code of who took it, and each pupil's
code and mark. It holds no names (the Builder puts the names back), no reasons and no notes.

**Lesson registers are not the statutory attendance register.** Your MIS remains the legal register
of attendance. These are lesson-by-lesson registers for internal monitoring and safeguarding.

## Data protection

Add the two new tables to your records of processing and DPIA (DATA-PROTECTION.md).

- **Timetable published** is replaced each time the timetable is published, so it never builds up.
- **Timetable register** grows by one row per register taken. Agree with your DPO how long to keep
  registers, for example until the end of the next school year. Then set a **bulk delete** job in the
  Power Platform admin centre (Environments, your environment, Settings, Data management, Bulk
  deletion). For example, delete Timetable register rows whose Register date is before a chosen date,
  each summer. Turning on **Auditing** for the register table records who changed what.

## If something is not right

| What you see | What to do |
|---|---|
| Staff app: "Not set up yet" | The Timetable published table is missing, or is named differently. Check step 2. |
| Staff app: "Nothing published yet" | Open the Timetable Builder app once, or choose Update the staff app now. |
| Staff app: "No access" | Give that person the Timetable staff role. |
| Staff app asks "Who are you?" | Their sign-in email does not match their email in the Builder (Setup, Staff). They can still look, but cannot take registers until it matches. |
| "Not published: … not allowed to write" | Give the Timetable editor role Create, Write and Delete on Timetable published. |
| Register will not save | Give the Timetable staff role Create (User) and Write (User) on Timetable register. |
| Lesson registers card: "cannot read" | Give the Timetable editor role Read (Organization) on Timetable register. |
