# The pupil Viewer

The pupil Viewer is a very simple, read-only page for **one pupil**. It answers three questions:
where do I go now, who is my adult, and is anything different?

## What a pupil sees

- **Hi** and their first name.
- **Now:** the lesson in large letters with its symbol, the room, and each adult as a coloured circle
  with their initials (or a photo, if the school added one) and their name.
- **A countdown:** six blocks that empty as the lesson goes on, with words such as "18 minutes until
  Break".
- **Next:** what comes next. Before school it says **First today** and the time. After school it says
  **School has finished** and what tomorrow starts with.
- **Today is a bit different** or **Tomorrow is different:** a calm, pale note with short sentences, such
  as "English is with Chloe, not Kezia." It never says why an adult is away, and nothing is shown in red.
- **My whole day:** the day as a list with symbols, ending with Home time, and a button for tomorrow.
- **Read to me:** reads the screen aloud. It only uses a voice that is on the device itself, so nothing is
  sent anywhere. If the device has no such voice, the button is not shown.
- **Aa:** text size (Normal, Big, Biggest) and letters (Normal, Easy read). Remembered on that device.

There are no menus, no search and no links. A pupil cannot reach anyone else's timetable, because it is
not in the file.

## Making the files

In the Timetable Builder: **Setup**, then **Pupil viewer**.

1. Choose a pupil and press **Download this pupil's Viewer**, or press **Download a Viewer for every
   pupil (.zip)** for one file each.
2. Give each file only to that pupil: on their own device, or in their own OneDrive or Google Drive.
3. Download again when the timetable changes. Each file shows the next school days with any cover (the
   same number as **School days ahead** in Staff viewer, and at least 5), then carries on with the usual
   week.

**Adults are shown as** a first name (Sam) or a full name (Sam Duffy). If two of a pupil's adults share a
first name, the first letter of the surname is added (Sam D).

## What is in a file, and what never is

| In the file | Never in the file |
| --- | --- |
| The pupil's first name | Their surname, code, year or any other detail |
| Their own lessons: subject, room, adults, symbol | Any other pupil's name, code or lessons |
| Adults' names and initials | Staff codes, emails, roles or notes |
| Which adult is covering | Why anyone is away |
| A photo of an adult, only if the school added one and that adult works with this pupil | Groups, class lists, the cover board, anyone else's timetable |

If another pupil's name has been typed into a lesson title or room name, it is taken out of the file.
The file can reach nothing: its security policy allows no connections at all.

A file cannot check who opens it. Who can see it depends on where you put it.

## Adult photos (optional)

In **Setup, Pupil viewer, Adult photos**: choose the adult, then **Choose a photo**. The picture is cut
square and made small (120 pixels) before it is kept with the timetable. It goes only into the Viewers
of pupils that adult works with, and never into the staff Viewer or the workbook. **Remove their photo**
takes it out. Ask the adult first, and add staff photos to your data protection records
(DATA-PROTECTION.md).
