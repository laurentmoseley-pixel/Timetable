# Sending the outbox with Power Automate

This is for the person who builds flows in Power Automate. It applies to the Power Apps edition,
where the timetable is kept in Dataverse.

In the app, **Tell people about changes** (the bell) can put messages in the **outbox**. Each
message is one row in the Timetable item table, of the kind `message`. A flow that your school
owns sends each message from your own Microsoft 365, then marks it as sent, or as not sent with the
reason. The app shows the result in the bell's Messages list.

The app itself never sends email. It keeps no web addresses, passwords or keys for flows. All of
that lives in the flow, under your school's control.

## What a message row holds

| Column | What is in it |
|---|---|
| Item kind (`<prefix>_itemkind`) | `message` |
| Name | The subject, for example `Cover on Tue 27 Oct` |
| Person code (`<prefix>_personcode`) | The member of staff's code |
| Person email (`<prefix>_personemail`) | Their email address |
| Item date (`<prefix>_itemdate`) | The date it was put in the outbox |
| Item data (`<prefix>_itemdata`) | The details, as JSON (see below) |
| Timetable code (`<prefix>_timetablecode`) | Which timetable it belongs to |

Item data looks like this:

```json
{"id":"M…","code":"JBR","email":"jo.bray@school.org.uk","subject":"Cover on Tue 27 Oct",
 "body":"Hello Jo,\n\nCover and other duties for you:\n- Tue 27 Oct, P2: 7B …\n\nThank you, Hillside School",
 "at":"2026-10-26T14:02:11.000Z","by":"Sam Office","status":"waiting"}
```

`status` is `waiting` when the app adds the message. The flow changes it to `sent` (with `sentAt`)
or `failed` (with `error`).

## Build the flow

1. In Power Automate, choose **Create**, then **Automated cloud flow**. Name it `Timetable outbox`.

2. **Trigger:** Microsoft Dataverse, **When a row is added, modified or deleted**.
   - Change type: **Added**
   - Table name: **Timetable items**
   - Scope: **Organization**
   - Filter rows: `<prefix>_itemkind eq 'message'` (use your own prefix, for example
     `cr4d2_itemkind eq 'message'`)

3. **Parse JSON.**
   - Content: the trigger's **Item data**.
   - Schema: choose **Use sample payload to generate schema** and paste the example above.

4. **Condition:** `status` (from Parse JSON) is equal to `waiting`, **and** `email` is not equal to
   an empty value.

5. **If yes:** Office 365 Outlook, **Send an email (V2)**. To send from a shared mailbox such as
   timetable@…, use **Send an email from a shared mailbox (V2)** instead.
   - To: `email` (from Parse JSON)
   - Subject: `subject`
   - Body: switch to the code view (`</>`) and use this expression, which keeps the line breaks:
     `replace(body('Parse_JSON')?['body'], decodeUriComponent('%0A'), '<br>')`

   To use Teams instead: Microsoft Teams, **Post message in a chat or channel**, posting as
   **Flow bot** in a **Chat with Flow bot**, with Recipient `email` and Message `body`.

6. **Mark it sent.** Add Microsoft Dataverse, **Update a row**.
   - Table name: **Timetable items**
   - Row ID: the trigger's **Timetable item** (the row's unique identifier)
   - Item data, as an expression:
     `string(setProperty(setProperty(body('Parse_JSON'),'status','sent'),'sentAt',utcNow()))`

7. **Mark it not sent if sending fails.** Add a second **Update a row** beside step 6, with the same
   table and Row ID.
   - Choose its **…**, then **Configure run after**, and tick **has failed** and **has timed out**
     for the send step.
   - Item data:
     `string(setProperty(setProperty(body('Parse_JSON'),'status','failed'),'error','Could not be sent. Check the address.'))`

8. Save the flow and turn it on.

## Check it

1. In the app, open the bell and choose **Put in the outbox** for one person.
2. Within a minute or two, the flow runs and the email arrives.
3. In the app, the bell's **Messages** list shows **Sent** after its next check for changes, within
   30 seconds or when you come back to the window.

## Good to know

- **Who runs it.** The flow runs as its owner's connection. Use a service account or a shared
  mailbox the school controls, and share the flow with a second owner so it does not stop when
  someone leaves.
- **No loops.** The flow only starts when a message is **added**. Marking it sent is a change, not
  an addition, so it does not run again.
- **Clearing the outbox** in the app deletes the rows. That does not start the flow.
- **Licences.** The Dataverse connector is a premium connector. A flow that only supports a Power
  Apps app can sometimes be covered by the app's licences. Check with your licensing admin before
  you rely on it.
- **Other editions.** In the single-file, Excel, Microsoft 365 and Google Sheets editions, there is
  no flow. Choose **Download the outbox (CSV)** for a mail merge, or send each message with the
  **Email** or **Teams chat** buttons from your own account.
- **Cover without the outbox.** SETUP.md section 8 has two more flows: one that messages people
  when they are given cover, and one that sends a morning summary.
