# Timetable Builder 3.0: final audit

**Date:** 26 October 2026
**Version audited:** 3.0.0 (single file, hosted, and Power Apps editions)
**Result:** ready to release. Every problem the audit found has been fixed, and each fix is now
covered by an automatic test.

## How the audit was done

1. **The brief.** Each requirement was checked against the app, with evidence (below).
2. **Attack tests.** Two new automatic tests try to break the app on purpose:
   - one fills a whole school with injection attempts
   - one sends rows from Dataverse that are built to cause harm
3. **The files that ship.** The finished files were scanned for secrets, keys, flow addresses,
   personal data and outbound addresses.
4. **Accessibility.** The industry rule set (axe-core 4.10, WCAG 2.0, 2.1 and 2.2, A and AA) was run
   on every page and the main windows, in light, dark and high contrast.
5. **Nothing removed.** The pages, menu items, controls, help topics, search jobs and downloads of the
   school's original app (`Timetable-builder (9).html`) were compared with 3.0.
6. **Speed.** Every page was timed on a made-up 1,500-pupil secondary school.
7. **Whole suite.** All automated tests were run on all three editions: about 1,300 checks across
   30 test files.

## The brief, point by point

| Requirement | Result | Evidence |
|---|---|---|
| Data only goes where the school chooses | Met | The single-file and hosted editions carry a content security policy. The browser blocks every connection except Microsoft sign-in and Graph, SharePoint downloads, Google Sheets and the app's own address. A test tries to send data elsewhere and is blocked. A scan of the shipped file found no other addresses it connects to. |
| No tracking or analytics | Met | No tracking, analytics or telemetry code. Nothing is fetched from the internet on start-up: fonts, symbols and libraries are built in. |
| Sanitise all imported text | Met (strengthened) | Every way in cleans the data: workbooks, CSV, backups, TimeTabler files, pasted lists, cloud workbooks and Google Sheets, Dataverse rows, and settings files. Text is always shown as text. CSV exports cannot carry formulas, and Google Sheets are written as plain values. |
| No passwords, keys, secrets or Power Automate trigger URLs in the HTML | Met | A scan of the shipped files for secret patterns (Google, AWS and Azure keys, client secrets, tokens, private keys, Power Automate signatures) found none. The setup screen refuses anything that looks like a secret. The outbox flow reads Dataverse rows; the app holds no flow address. |
| Cloud sign-in through the provider | Met | Microsoft uses MSAL with the delegated permission Files.ReadWrite.All (tested with the real MSAL library against a stand-in sign-in page). Google uses its own sign-in page. Tokens stay in the browser tab. |
| Role-based views: editors and read-only | Met (strengthened) | Three roles: change everything, cover and the day only, look only. They are enforced on every change, on Save and Ctrl+S, and on making, renaming or deleting scenarios. There is also the staff view. |
| Show which data source is active | Met | The chip in the header and the status bar, at all times. |
| Keep every feature that worked | Met | No page, menu item, control, help topic, search job or download of the original is missing. The one menu item that changed, Switch light or dark, became the four-way Appearance choice in step 6, as agreed. |
| No command-line steps for the school | Met | The single file opens by double-clicking. Hosting and cloud set-up are done in a browser (CLOUD-SETUP.md). The Power Apps edition is one file uploaded as a web resource (ADMIN-GUIDE.md, section 3). |

## Problems found and fixed

| # | What was found | Risk | Fix |
|---|---|---|---|
| 1 | Absences, extra-staffing requests, pupil absences and swaps brought in without period ticks (from older files, Dataverse rows or workbooks) stopped the Cover page and the extra-staffing list from drawing. | High: Cover unusable for that day | Such records now cover every period when they come in, and the tick boxes cope with them. |
| 2 | Rows written straight into Dataverse by another tool were not cleaned. A row key such as `__proto__` could change how parts of the timetable behaved. | Medium | Dataverse rows are now cleaned like every other way in, and dangerous keys are ignored. |
| 3 | Rows that were not in the saved order were added without being cleaned. | Low | They are now cleaned too. |
| 4 | Someone with look-only access could still make a scenario, which saves into the shared timetable, or press Ctrl+S. | Medium | Only people who can change everything can make, rename or delete scenarios. Saving tells look-only people there is nothing to save. |
| 5 | After a change was refused, the next message from the same click (for example "Moved") could still appear. | Low: misleading | Follow-on messages are held back for a moment after a refusal. |
| 6 | On a 1,500-pupil school, Setup took about 6 seconds to open and the Students page about 13 seconds. Every pupil's row carried a hidden list of every adult, and every class a list of every pupil (about 300,000 fields). | High for large schools | Those lists are now made only when opened. Big lists show the first 200, with the filter or Show all for the rest. Setup now takes 0.9 seconds and Students 1 second. |
| 7 | 43 accessibility rule failures: scrolling areas that could not be reached with the keyboard, unnamed fields (Auto build plans, Cover settings, Rota, the briefing), Help tabs with a property tabs do not take, and an unnamed search results list. | Medium | Every scrolling area can now be reached with the keyboard and has a name. Every field has a name, taken from its column and row, its label, or its hint. axe-core now reports no failures on any page, in any appearance. |
| 8 | Two of the school's real place names were used as examples (a text box hint and a guide). | Low: privacy | Replaced with neutral examples. |
| 9 | The welcome screen, added in step 10, covered pages in older tests, and touching browser storage too early in a test made a second window see empty storage. | Tests only | The test helper now closes the welcome screen after the page loads, without touching storage. |

## Results

| Check | Result |
|---|---|
| Injection attempts in every text field, across 30 pages and windows, printouts, the staff view and search | Nothing ran; no injected element appeared |
| Backups and Dataverse rows built to cause harm | Ignored safely |
| axe-core (WCAG 2.0, 2.1, 2.2 A and AA), every page and the main windows, 3 appearances, plus the welcome screen and an open scenario | 0 failures |
| Text contrast (own check) in 3 appearances, including a school's own colour | All text passes AA |
| Phone: 44 by 44 pixel touch targets, no sideways scrolling | Passes on every page |
| Secret and personal-data scan of the shipped files | None found. The demo school uses made-up names on example.org addresses. |
| Speed, 1,500 pupils: opening a page / making a change | Build 0.5 s / 0.5 s; Setup 0.9 s / 0.7 s; Students 1.0 s / 0.9 s; Cover 0.4 s / 0.3 s; Insights 0.3 s / 0.3 s |
| Whole automated suite | All passing |

## What this audit could not check

These are the steps to do before the first school relies on the app:

- **A real Microsoft tenant and a real Google Workspace.** Sign-in and saving were tested with the
  real MSAL library, against stand-ins for Microsoft's and Google's services. One trial in each,
  following CLOUD-SETUP.md, is needed.
- **A real Power Apps environment and a live Power Automate flow.** The Power Apps edition was tested
  against stand-ins for Dataverse. The outbox flow guide has not been run in Power Automate.
- **A screen reader in daily use.** The rule checks pass, but a short session with NVDA or VoiceOver
  is worth doing. The accessibility statement says the app has not had a third-party audit.
- **The school's DPIA.** DATA-PROTECTION.md gives the facts; the school's DPO makes the assessment.
