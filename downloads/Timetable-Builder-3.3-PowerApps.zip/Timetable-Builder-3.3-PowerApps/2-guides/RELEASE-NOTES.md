# Timetable Builder: release notes

Version 3.0 rebuilt the Timetable Builder as a product any school can use. It was released in ten
steps, each tested in full before the next. Nothing that worked before was removed.

## 3.3.0-preview.9 (11 November 2026)

- **Long lessons alongside the group:** making a lesson longer (or adding a subject that is usually
  longer) over periods that already have lessons now asks: **Keep both, for some pupils**, **Keep both,
  with the whole group**, or **Replace them**. Length goes up to the end of the day (it stopped at 6).
  The editor offers **Take them off the other lessons** when a pupil is in both.
- **Copying keeps what is there if you want:** Copy to other slots, and Copy the selection to other days,
  ask what to do with a lesson already in a slot: Replace it, Keep both, or Keep both and take these pupils
  off the other lesson. A lesson for part of a group starts on the last one.
- **Clashes:** the lesson card on hover says what the clash is.
- **One page each:** a printed staff or student timetable (One person, Print or Print all, and the
  vehicle timetable) now fits on one A4 landscape page. If a week is too full, it is printed slightly
  smaller, only as much as needed. Nothing is left out. The visual Week already fitted; the visual Day
  is still a page per day.
- **Print the whole timetable:** one master sheet with a row for each group, member of staff or room and
  every period of the week, with a key to the codes. A4 or A3, staff codes, rooms and colours on or off.
  On One person, Reports and Ctrl K.
- **Print by site:** the whole timetable can be printed for one site, or each site on its own pages, and
  One person has a **Site** choice for its list and Print all.
- **Summary of changes for all staff:** in the bell's window, one short list, by group, of new, moved and
  removed lessons, room and staff changes, and blocked time since the last summary was sent. No pupils,
  cover or reasons for absence. Copy it, email it or print it, then **Mark as sent**.
- **Blocked time:** PPA, ECT time, meetings, maintenance or other time can be blocked out in a person's
  week, in **Setup, Blocked time** (for several people at once) or by clicking an empty slot on **People
  and rooms, Staff**. No lesson is placed there, it never needs cover, and they are not asked to cover in
  it. Staff see the type on their timetable; the note stays in the Builder. The workbook's Staff sheet
  has a new **Blocked time** column.
- **Edit on People and rooms:** click a lesson on Staff, Students or Rooms and the lesson editor opens
  beside the grid, so you stay on that page. Click an empty slot to add a lesson for that person or room;
  for a pupil it goes on alongside the class with just them on it. Right-click gives the quick menu, and
  **Open in Timetable** goes to the same slot in the whole Timetable (what clicking a lesson used to do).
- **Show staff or pupils on One person:** on the Standard look, **Show: Staff** and **Pupils** choose
  whether each lesson lists them, on screen and when printed. Remembered on this computer.
- **Order on One person:** a new **Order** choice: Surname A to Z (the default), First name A to Z, or As
  in the list. It sorts the person list and **Print all**, and is remembered on this computer. Classes,
  rooms and vehicles sort A to Z.

- **Pupil Viewer:** Setup, Pupil viewer makes one file per pupil (one at a time, or a zip for everyone).
  It shows Now and Next with a symbol, the room and the adult (initials, or a photo if you add one), a
  countdown in blocks, "Tomorrow is different" notes, My whole day, Read to me (on-device voices only) and
  text size. Each file holds only that pupil's own timetable. See PUPIL-VIEWER.md.
- **Timetable grid:** hover over a lesson for a card with all of it (staff by name, students, room).
  **Compact** or **Comfortable** sets the size of lessons. The colour key and the long tips are folded into
  **Colour key and tips**, so more of the timetable shows. Nothing was removed.
- **Adding a lesson:** an empty slot suggests up to three lessons (what the class usually has at that
  time, with its usual adults and room, only if they are free then). One click adds it.
- **Tour:** a seven-step tour from Home or File, Help. **Saved** tick after each save. Shortcuts shown when
  you hover over Save, Undo and Search.
- **Staff Viewer:** a personal link (`#me=` and a staff code) opens straight on that person; **Copy my
  link** in Display and settings. Cover has a labelled **Cover** badge and a side bar in the day and week
  lists.
- **New school year:** File, New school year… makes next year from a copy in four steps (what to keep, year
  groups up with leavers, name, check). Download it as a file, or switch to it now: that asks first, takes
  a snapshot and downloads a backup before it changes anything, and Undo goes back.
- **Fix:** yes or no questions (for example "Clear cover choices?") now close with Escape or a click outside,
  sit above any other open window, and put the focus back where it was.
- **Meeting pack:** one click (Reports, Home or Ctrl K) prints staffing load, cover this term, room use
  and problems for an SLT meeting. Staff names only, no pupil data.
- **Cover page:** one main button, **Cover this day**. The four print and copy buttons are in one **Print
  or copy** menu. Several days, Redo and Clear are under **Several days, redo or clear**; Clear still asks
  first. Nothing was removed.
- **Today:** the Getting started list folds itself once 7 of 9 are done, and says what is left. **Show**
  opens it and it then stays open.
- **Fix:** jumping to a section in Setup no longer shifts the whole window.

## 3.3.0-preview.8 (10 November 2026)

- **Home:** the app now opens on **Home**. **To do** lists what needs you today, each with one button
  that goes to the job: lessons nobody covers, clashes, lessons still to place, staff below your
  minimums, transport to book, unsaved work and backups. Below are headline numbers, safety and
  staffing through the day, cover so far this term and quick jobs.
- **Plainer menu:** Build is now **Timetable** and Scenarios is **What if**. Staff, Students and Rooms are
  one item, **People and rooms**, with a switch at the top of each. Subject choices (was Options), Rest
  days and on call (was Rota), Transport and One person (was Individual) are under **More**, which stays
  open once opened. Search still finds the old names. Nothing was removed.
- **Swap or replace a person:** one window from Home, One person, a lesson's quick menu or Ctrl K. Choose who
  comes off, which lessons (one, a class's, or all) and who goes on. Free people come first. Clashes are shown
  **before** you confirm, with the choice to leave those lessons where they are. About 4 clicks instead of 7.
- **Quick menu on a lesson:** right-click, Shift+F10 or a long press on the Timetable grid: Edit, Swap or
  replace, Change room, Copy to other slots, No staff needed, Lock or Unlock, Delete.
- **Room list:** in the lesson editor, free rooms come first, and rooms in use say what is in them.
- **Staff Viewer, Today:** opens on Today, with the Updated time, **Today's changes** (cover, room changes,
  lessons not with you), and **Now and Next** all day: before school, during lessons (Room, Group, With on
  their own lines and the minutes left), at break and after school (what tomorrow starts with). One search
  box finds a colleague, room or group. Four tabs: Today, Week, Find, Cover. **Display and settings** adds
  text size and an easier-to-read font. Buttons are at least 48 pixels. Reasons for absence are never shown.

## 3.3.0-preview.7 (10 November 2026)

- **Two lessons in one period (halves):** mark a lesson **First half** or **Second half** of its period, in
  the lesson editor, for a selection, or by dropping one lesson on another and choosing **One after the
  other**. Halves never clash, even with the same staff and students, and the bell times do not change.
  They show as 1st half and 2nd half on the Build grid, in the staff Viewer (grid, day and visual
  timetables) and in a new **Half** column on the workbook's Lessons sheet.
- **Drag and drop:** dropping a lesson on another no longer deletes it without asking. A menu offers
  **Swap places**, **Merge into** (one lesson with both sets of staff and students), **One after the other**,
  **Keep both at the same time** and **Replace**. Next to the same subject, it can join them into a double.
  Dropped into another class, a whole-class lesson takes that class's list.
- **Merging lessons in one period:** where a class has several lessons in a period (for example three 1:1s),
  drop one onto another and choose **Merge into**, or use **Merge these into one** in the lesson editor, or
  **Merge each period into one lesson** for a selection. Dropping on another lesson in the same period now
  works (before, nothing happened). The editor's tabs show each lesson's student, so they can be told apart.
- **Reports, Who is doing what:** search the timetable for a subject, lesson title, room or group, such as
  **Reduced timetable** or **Alternative provision** (one-click buttons for these and Off site, 1:1, College and
  Not on site). It lists each student and member of staff on those lessons, with periods a week and when,
  every matching lesson, and a spreadsheet download. Words match loosely: alternate, alternative, Alt and
  AP count as alternative provision, and TT as timetable.
- **Tidy names:** Setup, Subjects suggests names that look like the same thing (for example Alt Provision,
  Alternative Provision and every "AP - ..." name; Off Site and Offsite PLG's) and merges the ticked ones
  into one name in a click. Or tick subjects yourself and choose **Merge into one**. Every lesson, plan,
  option, specialism and code follows, and each lesson keeps its old name as its title with a start you choose, so it still
  says which provision it is (AP - Player Ready becomes Alternative provision, titled AP: Player Ready). Rooms can be merged the same way in Setup, Rooms.
  In Reports, **Change all of these lessons** gives every lesson a search finds one subject or title.
- The whole-school **Split in half** button for periods, added earlier today, is gone; halves replace it.
- **Whole-week changes where a class has more than one lesson in a period** (for example a 1:1 beside
  the group, or the group split in two):
  - Adding a member of staff or a student to all of a selection's lessons (or with **Add to class team
    and all its lessons**, or **Put on all its lessons** in Auto build) puts them in one lesson per period:
    the main one, with most students. They are never put in two lessons at once, and the app says where
    the class was split.
  - Adding a pupil to a class list does the same.
  - **Set to class list** leaves pupils in their 1:1 or small group; the main lesson gets the rest.
  - **Copy the selection to other days** copies every lesson in each period. Before, only the last
    one was kept.
  - **Join into one block** joins each set of students with itself across the periods.
- **Setup bars** keep the class or person you chose, so one action can follow another.
- **Printing** a page no longer copies its ids. In Insights, links and labels could point at the
  printed copy.
- The file pickers for uploading staff and lesson spreadsheets now have names for screen readers.

## 3.3.0-preview.6 (10 November 2026)

- **Checks, Students with no staff:** a lesson with students on it and no staff is a rule broken, marked
  red on the Build grid and in the lesson editor. Where staff are not needed (college, work experience,
  an off-site placement), tick **No staff needed for this lesson**, or **No staff needed for any ... lesson**
  for the whole subject. Both are in the lesson editor, as buttons in Checks, and as a column in
  Setup, Subjects.
- **Staff Viewer:** **Change**, next to the name at the top, opens the list of names to look at someone
  else's timetable. It is not shown in a personal Viewer, or in Power Apps, where staff are signed in.
- Fixed: in the Viewer, the Future look could switch the timetable view, and so could clicking the page in
  that look.

## 3.3.0-preview.5 (10 November 2026)

- **Staff Viewer, Students:** type part of a student's name and see their week. It appears only when
  **Student timetables** is ticked in **Setup, Staff viewer**, because it puts every timetabled student's
  name, year and tutor group in the staff copy. Nothing about which student was looked up is kept.
- **Staff Viewer, on a computer:** My week, Staff, Students, Rooms and Groups show the week as a grid like
  the Builder's Staff and Students pages, in subject colours, with group, room, staff and students.
  **This week, with cover** includes that week's cover and rest days. Phones keep the day cards; My day is
  unchanged.
- **Staff Viewer, visual timetables:** on Students and Groups, **Visual week** and **Visual day** use the
  Builder's picture symbols. **Print** prints the one on screen.
- **Staff Viewer, Show:** ticks for **Adults**, **Students**, **Rooms** and **Groups** on each lesson, down to
  just the subject. Each person's choice is remembered on their own device.
- **Staff Viewer, My week** opens on the usual week. New timetables publish 5 school days ahead instead of
  10 (Setup, Staff viewer).
- **Setup, Staff:** tick people, choose a class, then **Add to class team and all its lessons**,
  **Team only** (the old Add to class team) or **Take off all its lessons**. Also **Take off every lesson**
  (asks first; they stay on the staff list) and **Swap on all their lessons** (the person chosen in
  **Swap for…** takes over every lesson and class team place). Each says how many lessons changed and
  how many clash (see Checks). Undo puts it back.

## 3.3.0-preview.4 (10 November 2026)

- Fixed: opening a workbook, or bringing in **Rooms** from a backup, kept the room names but lost
  each room's type, capacity, site and **Can be shared**. They now come in with the rooms. Without
  this, rooms had no site after importing, and shared rooms (such as off-site provision) showed as
  double-booked.

## 3.3.0-preview.3 (10 November 2026)

Sites on the Build grid, for schools on more than one site (USER-GUIDE.md, "More than one site").

- **Build:**
  - Classes are grouped under a heading for each site, with the site's colour down the row.
  - A new **Site** menu shows one site at a time, and **Group by site** can be turned off. The app
    remembers both on this computer.
  - A lesson in a room on another site from its class shows that site's name.
- **Setup, Classes and groups:** a new **Site** column. Left blank, it shows the site taken from the
  class's rooms. **Set site** works on several classes at once.
- **Workbook:** the Groups sheet has a new **Site** column after Phase. Workbooks without it still
  import, and keep each class's site.
- **Rooms** shows each room's site. The lesson editor's room list names rooms on another site.
- Nothing changes for a school with no sites set. Nothing was removed.

## 3.3.0-preview.2 (9 November 2026)

Live cover for staff computers, without Power Apps (STAFF-VIEWER.md, "Live cover on staff computers").

- **Builder, Setup, Staff viewer:**
  - **Choose the shared folder…**: pick a staff SharePoint library synced by OneDrive. The staff copy is saved there within seconds of every change, and again each new day.
  - **Put the Viewer in this folder** saves the Viewer there for staff.
  - No links, keys, flows or app registration are needed.
- **The Viewer:**
  - **Choose the folder…** connects it to the same synced folder.
  - It shows **Live**, checks every 20 seconds, and shows each change by itself, with **changes since you last looked**.
  - It works in Edge and Chrome on computers.
- Fixed: the Power Apps staff copy could be published again every 45 seconds even with no change. It now goes out only after a real change, or once a new day starts.

## 3.3.0-preview.1 (9 November 2026)

The staff app for Power Apps, with lesson registers. POWER-APPS-STAFF-APP.md has the set-up steps.

- **Two apps in Power Apps.** The Timetable Builder stays the SLT build app. The Viewer becomes a second web resource and model-driven app for staff, **Timetable Viewer**.
- **The staff app knows who is signed in**, so nobody has to choose their name. It shows their day, with Now and Next, their week, cover, rooms, groups and staff, as the school chooses.
- **Staff never need access to the main timetable table.** The Builder writes a staff-safe copy to a new **Timetable published** table:
  - by itself, within a minute of each change and each morning
  - or when you choose **Setup, Staff viewer, Update the staff app now**
- **Lesson registers.**
  - **Take register** appears on each lesson or cover a person has today, from 5 minutes before it starts.
  - Each pupil is marked Present, Late, Absent or Out of lesson. Pupils reported off are already marked Absent, with no reasons shown.
  - Registers are saved to a new **Timetable register** table, as pupil codes and marks only. Corrections update the same register.
- **Today, Lesson registers** (Builder, Power Apps):
  - each group in each period: who took the register, when, and the counts
  - missing registers flagged once the period is over
  - a download with pupil names
- **Check the staff app tables** names any missing column, or any column that is too short.
- The single-file edition and the file Viewer work as before. Copies saved as files hold no pupil lists and no sign-in codes.

## 3.2.0-preview.4 (28 October 2026)

Step D: the staff Viewer.

- **Setup, Staff viewer** (or **File, Publish for staff**): publish a staff-safe copy of the timetable and download the read-only Viewer for all staff, a Viewer for each person (a zip), or the published copy on its own (`timetable-published.json`, for a Viewer on the school's web site, which then loads the newest copy itself).
- **The Viewer**, phone first: My day with **Now** and **Next**, My week (this week with cover, or the usual week), Cover, Rooms, Groups and Staff. It lists **what changed since you last looked**. A rest day or a day away is one line. When a copy has run out, it says so.
- **What staff can see** is the school's choice: anyone's timetable, rooms, groups, the cover board, and who is away (names only, never why). A personal Viewer holds only its owner's days.
- **Never in a copy:** pupils, emails, pupil numbers, absence reasons or types, notes, notices or cover work. A pupil's name in any text becomes "a pupil".
- Matches the Builder: Automatic, Light, Dark, High contrast; Classic or Future; the school's colour and logo. Read only, no AI, and it reaches nothing but its own web site.
- **Setup, AI assistant** now lists where every AI button is, with **Go there**.
- Guide: STAFF-VIEWER.md.

## 3.2.0-preview.3 (28 October 2026)

AI assistant, step C: the action library and the no-code builder.

- **Setup, AI actions** lists every AI button. The seven official actions are locked: switch any off, view how it works, or duplicate it to make your own version.
- **New action**: a form for a custom button, with no code. Choose what it does, where it goes, the data it may send (as codes), the prompt with placeholders, and how many attempts it gets. The checks an action needs are always on. Problems are shown as you type.
- **Preview what it sends** (from a made-up school; nothing is sent) and **Try it on practice data** (the same gateway, checks and review, on the made-up school, never applied).
- Versions: each save is numbered, the last 10 are kept, and any can be loaded back. Delete asks first, and Undo brings an action back.
- Packs: share one action, or all of yours, as a file. Bringing a pack in cleans every action, refuses any with a key, an email or one of your people's names in it, and leaves the rest switched off until someone has looked.
- Names: a whole name, staff code or email in a prompt cannot be saved. A word that is also part of a name (like "will") must be confirmed as an ordinary word for that prompt. Typed questions get no such allowance.
- Actions with a typed question work anywhere: the app asks when the button is pressed, with the list of people, groups and rooms.
- **Fixed: Claude did not answer.** The app sent Claude a setting (temperature) that the newest Claude models refuse, so every request failed. Checked live against Claude: the connection test and Fix all clashes both work.
- **Setting up is guided**: numbered steps (turn on, service, AI-enabled copy, key, model, test) with a "Next:" line. The key box is only in the AI-enabled copy, where the key is used. Enter in the key box now works, and the models are found straight away. Test the connection says exactly what is missing.
- Fix all clashes now tells the AI where each problem lesson could go (the app's own Where it fits), so it usually succeeds first time, even with small, cheap models.
- Guide: AI-ACTION-TEMPLATES.md (the template format, places, placeholders, data, checks, answer formats and packs), with an example pack of six actions.

## 3.2.0-preview.2 (28 October 2026)

AI assistant, step B: the action buttons. Optional; they appear only when the AI assistant is on, and
only for people who can change everything.

- Seven buttons where the work happens: **Fix all clashes** (Build toolbar), **Timetable this class** (Auto build, each group), **Find cover** (Cover, each person off that day), **Balance this week** (Individual, a member of staff), **Explain this placement** (the lesson editor), **Run a what-if** (Scenarios, with a scenario open) and **Map my spreadsheet** (Upload sheets, when a lessons sheet's headings are not recognised).
- The AI only proposes. The app applies each proposal to a copy and checks it with its own rules. If anything fails, the reasons go back to the AI to try again, five times at most; then it stops and nothing changes.
- You see the result before and after, with every change listed: Approve, Edit (untick changes; the rest is checked again) or Reject. Approving is one change, so Undo puts it back.
- Safety: an action for one group or person cannot touch anyone else's lessons; locked lessons never move; Fix all clashes must leave fewer problems than before; cover respects free periods, working days and the daily cover limit; what-ifs only ever change the open scenario.
- In a what-if, insert people, groups and rooms from the list (they go as codes). Typed names are refused, not sent.
- Tested on Claude, OpenAI and a local model with a stand-in AI that only sees codes, including AIs that break rules, invent codes, send malformed answers and put script in their notes. Across every request in the tests, no name, email, staff code, group or room name left the app.

## 3.2.0-preview.1 (28 October 2026)

AI assistant, step A: the privacy gateway and the AI connections. Optional; off unless turned on.

- Setup, AI assistant: choose Claude, OpenAI, Google Gemini, Azure OpenAI, a local model (Ollama) or the school's own relay; find models; test the connection; see exactly what is sent.
- Names never leave the app. Each action sends only the data it needs, as codes shuffled for every request. The whole request is checked for names, emails, codes and notes, and blocked if one is found.
- Answers must fit a strict format: retried once with the errors, then refused safely. Made-up codes are refused.
- The key stays in memory, or is remembered encrypted with a passphrase; never in the timetable or the file.
- The app can only reach the chosen AI service from the AI-enabled copy you download from Setup.
- The AI log keeps every request and answer, in codes.
- Guides: AI-PROVIDERS.md (setting up each service, adding a new one) and AI-PRIVACY.md (for the DPO).

## 3.1.0-preview.1 (26 October 2026)

A visual trial: the Future look. Only the look changes.

- File menu (and Ctrl+K): Look, Classic or Future, remembered on this computer, and Reduce effects. Classic is unchanged.
- Future combines Glass HQ with Mission Control: floating glass panels over a still background light, frosted windows and menus, the school's colour as the glowing accent, Space Grotesk headings and JetBrains Mono for times, codes and counts, lit lesson tiles, glowing drop targets, a steady red ring on clashes with a gentle pulse on the problem count, and a floating dock on phones.
- Works in Dark, Light and Automatic. High contrast, printouts and Windows forced colours always use the plain style. Reduce effects, and the computer's reduced motion and transparency settings, turn off blur, glow and movement.
- Checked: WCAG 2.2 AA text contrast against the lightest part of any glass, with any school colour; no axe-core failures; 44 px touch targets; as smooth as Classic when scrolling a 1,500-pupil timetable; every functional test passes in Future.

## 3.0.0 (26 October 2026)

The full release, after a final audit against the brief. docs/AUDIT-REPORT.md has the results.

- Checked with two new attack tests (injection attempts in every field, and harmful Dataverse rows), a scan of the shipped files for secrets, personal data and outbound addresses, axe-core on every page in every appearance, and a feature-by-feature comparison with the original app.
- Absences, extra-staffing requests, pupil absences and swaps without period ticks (from older files, Dataverse rows or workbooks) now cover every period instead of stopping Cover.
- Rows written straight into Dataverse are cleaned like every other way in; dangerous keys are ignored.
- Only people who can change everything can make, rename or delete scenarios. Saving tells look-only people there is nothing to save.
- Large schools: Setup and the Students page open in about a second with 1,500 pupils (were 6 and 13 seconds). Long lists show the first 200, with the filter or Show all for the rest.
- Accessibility: every scrolling area can be reached with the keyboard, every field has a name, and axe-core finds no WCAG 2.2 A or AA failures.

## 3.0.0-preview.10 (26 October 2026)

Step 10: ready for other schools.

- Who can change the timetable: Can change everything, Cover and the day only, or Can look, not change, by the email people sign in with (Microsoft 365, Google, Power Apps). Nobody can lock themselves out. The status bar says when you can only look.
- The school's look: a logo (menu, staff view, printouts) and a colour, adjusted automatically so text on it meets WCAG 2.2 AA in light and dark.
- Welcome screen for a new timetable: a demo school to look around, the school day step by step, or bring in a workbook, the template, TimeTabler files or a backup.
- Help and guides (File menu, status bar, Ctrl+K): a guide to each part, What's new (shown once after an update), and About: version, where data is kept, licences, and a support contact the school's IT team can set.
- Personal data (Setup): everything held about one person, for a subject access request, and removing day-to-day records from before a date. Both are recorded in the change log.
- The outbox shows what the school's Power Automate flow has sent, or why not.
- Documentation: README, user guide, IT and admin guide, Power Automate outbox flow, data protection, accessibility statement, release notes.

## 3.0.0-preview.9 (26 October 2026)

Step 9: cloud storage and the hosted app.

- Where your data is kept: Excel in OneDrive or a SharePoint library (Microsoft 365), and Google Sheets, with each person's own school sign-in: Microsoft through MSAL (delegated permission Files.ReadWrite.All), Google through its own sign-in page. Open a workbook from a pasted link or the recent list, save to a new one, save over it, and carry on after a reload.
- Saving never overwrites someone else's save without asking: a copy of your version goes to your downloads, then you choose to open theirs or save yours over it.
- Cloud sign-in (for IT): enter the app IDs (never a secret: anything like one is refused), try them on one computer, then download the app for the school's web site with them built in, or a timetable-config.json to put next to it. CLOUD-SETUP.md has the steps, all in a browser.
- A copy on a web site says it cannot save into itself and offers where to keep the timetable.
- A content security policy: the single-file app can only connect to Microsoft sign-in and Graph, SharePoint downloads, Google Sheets and the page's own web site. Nothing else, ever.
- src/lib/cloud.js; MSAL Browser 4.30 (MIT licence) is built into the file.

## 3.0.0-preview.8 (26 October 2026)

Step 8: insights and scenarios.

- Insights page (Plan): headline numbers, workload for teachers and support staff with each person's most a week, staff free to cover in every period, rooms in use, groups against their weekly plans, pupils with no lesson, and whether cover is shared fairly this term. Each part downloads as a spreadsheet (CSV), and the page prints. Worked out by src/lib/insights.js.
- Scenarios page (Plan): full working copies of the timetable's plan (lessons, groups and weekly plans, staff, subjects, rooms, rules) to try things out. Open one and every planning tool works on it; the real timetable, cover and day-to-day pages are untouched and stay what is saved. Compare up to three with the real timetable, see what is different (also outlined on Build), download one as Excel, and use the best as the real timetable (a snapshot first; Undo works).
- Dataverse: each scenario is a row of the kind scenario. Excel and CSV keep them in App data.

## 3.0.0-preview.7 (26 October 2026)

Step 7: telling people.

- A bell in the header counts staff with changes they have not been told about: new or cancelled cover and other duties for the next few school days, being called in from a rest day, and changes to their weekly timetable.
- Tell people lists them with each change and a ready-written message. Send it by email from your own mail program, as a Teams chat, as copied text, or as a calendar file (.ics) with each duty, or put it in the outbox. Mark people as told; Undo works as usual.
- The outbox: in the Power Apps version each message is a Dataverse row (kind message) with the email address in its own column, for a Power Automate flow your IT team sets up to send. No passwords, keys or flow web addresses are kept in this app. Elsewhere it downloads as a spreadsheet for a mail merge.
- Optionally, this computer can tell you when Build the whole timetable finishes while you are in another window.

## 3.0.0-preview.6 (26 October 2026)

Step 6: the interface.

- One design system on every page: calm light appearance (indigo on warm white), the dark control room (deep slate with a cyan accent), and a new high-contrast appearance. Choose Automatic, Light, Dark or High contrast in the File menu or with Ctrl+K.
- Inter is the interface font, built in (nothing fetched); the easier-to-read font stays.
- Lesson tiles show a tint of the subject colour with a coloured code chip, readable in every appearance whatever colours a school picks.
- The header names the page and its section; a status bar shows where the data is, whether it is saved, problems to put right and the quality score (click for Checks), and the size of the timetable. Press ? for keyboard shortcuts.
- Phones: the menu becomes a bar along the bottom, toolbars scroll sideways, the lesson editor is a sheet from the bottom, and every control is at least 44 by 44 px on a touch screen.
- All text meets WCAG 2.2 AA contrast in all three appearances (checked automatically); windows open with a short animation, which stops when the computer asks for less motion.

## 3.0.0-preview.5 (26 October 2026)

Step 5: cover upgrades.

- This week: each school day's cover at a glance (needed, found, people away, work set); click a day to open it.
- Work for covered lessons: typed on the Cover page for each lesson, or once for all of an absent colleague's lessons. It goes on the cover slips, the Staff day page and the staff view, with web addresses as links. Each absence says how much work is set.
- Cover limits a term: a usual limit for teachers and for support staff, and a person's own limit (Cover record, or Cover limit per term on the Excel Staff sheet). Auto cover uses anyone over their limit only when nobody else is free, and says so; every list shows how far each person is through their limit.
- The cover record downloads as a spreadsheet (CSV): every cover since the start date.
- Dataverse: work is kept one row per lesson per day.

## 3.0.0-preview.4.1 (26 October 2026)

Fix: pupils' timetables were empty when lessons listed no pupils.

- A lesson whose Pupil codes are blank (on the Excel Lessons sheet, a CSV folder, or an uploaded lessons sheet) now takes everyone on its group's class list. None means no pupils.
- Opening a workbook says when this has been done, and warns when lessons have no pupils and their groups have no class list.

## 3.0.0-preview.4 (26 October 2026)

Step 4: live checking.

- Dragging a lesson colours its class's row: green where it fits, amber where it fits but replaces a lesson or repeats the subject that day, red where it would break a rule. Dropping where it breaks a rule asks first.
- Alt and the arrow keys move the chosen lesson a period or a day at a time, swapping with a lesson of the same length that is in the way, and say whether it fits.
- Lesson editor: Where it fits (free slots, one click to move) and Fix it for me (the scheduler finds the best place, moving as little as possible, and shows the changes first).
- Snapshots (File menu): keep a copy of the lessons, compare with now, outline what changed on the Build page, or go back. One is taken automatically before Build the whole timetable is used and before going back. Saved with the timetable, in Excel and Dataverse.
- Checks window: a button to fix everything with Build the whole timetable.

## 3.0.0-preview.3 (26 October 2026)

Step 3: the auto-scheduler (src/lib/scheduler.js).

- Auto build page: Build the whole timetable. Fill the gaps from each class's weekly plan, improve what is there, or rebuild from the plans, for every class or one. It keeps to the rules and raises the quality score, runs in a background worker (or on the page where a browser will not allow one), shows progress, can be stopped, and shows the result before anything changes. Undo puts it back.
- Locked lessons never move: lock one in the lesson editor, several with the multi-select editor, or a whole class on the Auto build page. Option blocks are always kept.
- Weekly plan rows can say who teaches them ("Taught by"); Place missing lessons uses it too.
- Excel: Locked column on the Lessons sheet, Staff codes column on the Curriculum sheet.

## 3.0.0-preview.2 (26 October 2026)

Step 2: the rules engine (src/lib/rules.js).

- One set of rules used everywhere: double-bookings, rest days and part-time hours, room capacity, room type, staffing ratios, pupils kept apart, time to move between sites.
- Two-week timetables: a Week A lesson and a Week B lesson in the same period no longer clash.
- Checks button on the Build page: rules broken, things worth fixing, and a quality score out of 100 with what each part costs. The school chooses how much each part counts, which subjects are core, and how long it takes to move between sites.
- Setup: room type for subjects; type, capacity, site and "can be shared" for rooms. These are on the Excel workbook too (Subjects, Rooms and School sheets).

## 3.0.0-preview.1 (26 October 2026)

Step 1 of the product rebuild: the data layer.

- Data model 3.0, documented below (search for DATA MODEL 3.0): two-week cycle, room type, capacity and site, pupils kept apart, key adults. Older timetables are brought up to date.
- Where your data is kept (File menu, or the chip by the Save button): inside this file, an Excel workbook, or a folder of CSV files; Dataverse in the Power Apps version. Test the connection, export everything to Excel, download the Excel template.
- Built-in Excel reader and writer (src/lib/xlsx.js). The app no longer fetches anything from the internet: the Excel library and the easier-to-read font were downloaded before.
- Workbooks are checked on opening, with plain-English problems; nothing is used until errors are put right. A backup to Excel is offered before bringing data in or opening a workbook.
- Everything brought in is made safe first; CSV exports can no longer carry spreadsheet formulas.
- "Keep unsaved work on this computer" can be turned off on a shared computer.

## 2.7.3 (21 October 2026)

TimeTabler Room exports.

## 2.7.2 (13 October 2026)

Staff day, 1:1 adults freed for cover, faster printing, symbols.

